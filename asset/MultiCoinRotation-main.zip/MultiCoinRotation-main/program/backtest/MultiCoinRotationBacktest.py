import pandas as pd
import numpy as np
from function import *
from signals import *
import matplotlib.pyplot as plt
from functools import reduce
pd.set_option('expand_frame_repr', False)  # 当列太多时不换行
pd.set_option('display.max_rows', 5000)  # 最多显示数据的行数

# 设置参数
hold_period = '1D'  # 持仓周期
trade_rate = 2.5 / 1000  # 千分之2.5的交易费用远高于市场平均水平
para = 20  # 计算周期数
factor = 'gap'
# factor = 'momentums'

# 回测时间
start_time = '20190101'
end_time = '20210801'

# 历史数据格式样例: ..\spot\BTC-USDT.pkl
path = r'/Users/zhanglianzhong/PythonStudyWorkspace/中性回测框架/coin_alpha_compound_backtest_v2/6-中性策略优化-回测部分/coin_alpha_compound_backtest/data/backtest/swap/output/pickle_data'

# 轮动组
rotation_list = ['BTC', 'ETH', 'BNB','UNI']


def main():
    symbol_data = form_data_dict(path, rotation_list, hold_period, start_time, end_time, factor, para)

    # 合并数据
    dfs = [symbol_data[symbol] for symbol in rotation_list]
    df = reduce(lambda left, right: pd.merge(left, right, on='candle_begin_time', how='left'), dfs)

    # 筛选要对比列
    compare_column_list = [symbol + '_' + factor for symbol in rotation_list]

    # 求出最大值以及最大值对应的币种
    df['max'] = df[compare_column_list].max(axis=1)
    _df = df[compare_column_list]
    _df = _df.apply(lambda x: appendmax(x), axis=1)
    _df.columns = compare_column_list + ['style']
    df['style'] = _df['style'].str.strip('_' + factor)
    df.loc[df['max'] < 0, 'style'] = 'USDT'

    # 相等时维持原来的仓位。
    df['style'].fillna(method='ffill', inplace=True)

    # 收盘才能确定风格，实际的持仓pos要晚一周期。
    df['pos'] = df['style'].shift(1)

    # 删除持仓为nan的天数
    df.dropna(subset=['pos'], inplace=True)

    # 计算策略的整体涨跌幅strategy_pct
    for symbol in rotation_list:
        df.loc[df['pos'] == symbol, 'strategy_pct'] = df[f'{symbol}_pct']
    df.loc[df['pos'] == 'USDT', 'strategy_pct'] = 0

    # 调仓时间
    df.loc[df['pos'] != df['pos'].shift(1), 'trade_time'] = df['candle_begin_time']

    # 将调仓日的涨跌幅修正为开盘价买入涨跌幅
    for symbol in rotation_list:
        df.loc[(df['trade_time'].notnull()) & (df['pos'] == symbol), 'strategy_pct_adjust'] = df[f'{symbol}_close'] / (
            df[f'{symbol}_open'] * (1 + trade_rate)) - 1
    df.loc[df['trade_time'].isnull(), 'strategy_pct_adjust'] = df['strategy_pct']

    # 扣除卖出手续费
    df.loc[(df['trade_time'].shift(-1).notnull()) & (df['pos'] != 'empty'), 'strategy_pct_adjust'] = (1 + df[
        'strategy_pct']) * (1 - trade_rate) - 1

    # 空仓的日子，涨跌幅用0填充
    df['strategy_pct_adjust'].fillna(value=0.0, inplace=True)
    del df['strategy_pct'], df['style']
    df.reset_index(drop=True, inplace=True)

    # 计算净值
    for symbol in rotation_list:
        df[f'{symbol}_net'] = df[f'{symbol}_close'] / df[f'{symbol}_close'][0]
    df['strategy_net'] = (1 + df['strategy_pct_adjust']).cumprod()

    # 评估策略的好坏
    res = evaluate_investment(df, 'strategy_net', time='candle_begin_time')
    print(res)

    # 绘制图片
    plt.plot(df['candle_begin_time'], df['strategy_net'], label='strategy')
    for symbol in rotation_list:
        plt.plot(df['candle_begin_time'], df[f'{symbol}_net'], label=f'{symbol}_net')
    plt.legend()
    plt.show()
    # 保存文件
    print(df.tail(10))
    df.to_csv('数字货币轮动_多币种.csv', encoding='gbk', index=False)


if __name__ == '__main__':
    main()
