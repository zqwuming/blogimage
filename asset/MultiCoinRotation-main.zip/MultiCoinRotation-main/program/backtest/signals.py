import pandas as pd
import talib as ta


def signal_momentums(df, n=1):
    """
    邢大原版因子
    """
    df['momentums'] = df['close'].pct_change(periods=n)

    return df


def signal_gap(df, n=1):
    ma = df['close'].rolling(window=n).mean()
    wma = ta.WMA(df['close'], n)
    gap = wma - ma
    df['gap'] = gap / abs(gap).rolling(window=n).sum()

    return df