import pandas as pd
from signals import *
from multiprocessing import Pool, cpu_count


def deal_single_file(path, symbol, hold_period, start_time, end_time, factor, para):
    df = pd.read_pickle(path + f'/{symbol}-USDT.pkl')
    df = df[df['candle_begin_time'] >= pd.to_datetime(start_time)]
    df = df[df['candle_begin_time'] <= pd.to_datetime(end_time)]
    df.set_index('candle_begin_time', inplace=True)
    agg_dict = {
        'open': 'first',
        'high': 'max',
        'low': 'min',
        'close': 'last',
    }
    df = df.resample(hold_period).agg(agg_dict)
    df.reset_index(inplace=True)
    df[f'{symbol}_pct'] = df['close'].pct_change(1)
    eval(f'signal_{factor}')(df, int(para))  # 计算信号

    # 重命名行
    df.rename(columns={'open': symbol+'_open', 'high': symbol+'_high', 'low': symbol+'_low',
                       'close': symbol+'_close', factor: symbol + '_' + factor}, inplace=True)

    return symbol, df


def form_data_dict(path, rotation_list, hold_period, start_time, end_time, factor, para):
    arg_list = [(path, symbol, hold_period, start_time, end_time, factor, para) for symbol in rotation_list]

    with Pool(processes=10) as pl:
        # 利用starmap启用多进程信息
        result = pl.starmap(deal_single_file, arg_list)

    df = dict(result)

    return df


def appendmax(sr):
    one = sr.idxmax()
    maxindex = pd.Series(one)
    sr = sr.append(maxindex)

    return sr


def evaluate_investment(source_data, tittle,time='交易日期'):
    temp = source_data.copy()
    # ===新建一个dataframe保存回测指标
    results = pd.DataFrame()

    # ===计算累积净值
    results.loc[0, '累积净值'] = round(temp[tittle].iloc[-1], 2)

    # ===计算年化收益
    annual_return = (temp[tittle].iloc[-1]) ** (
            '1 days 00:00:00' / (temp[time].iloc[-1] - temp[time].iloc[0]) * 365) - 1
    results.loc[0, '年化收益'] = str(round(annual_return * 100, 2)) + '%'

    # ===计算最大回撤，最大回撤的含义：《如何通过3行代码计算最大回撤》https://mp.weixin.qq.com/s/Dwt4lkKR_PEnWRprLlvPVw
    # 计算当日之前的资金曲线的最高点
    temp['max2here'] = temp[tittle].expanding().max()
    # 计算到历史最高值到当日的跌幅，drowdwon
    temp['dd2here'] = temp[tittle] / temp['max2here'] - 1
    # 计算最大回撤，以及最大回撤结束时间
    end_date, max_draw_down = tuple(temp.sort_values(by=['dd2here']).iloc[0][[time, 'dd2here']])
    # 计算最大回撤开始时间
    start_date = temp[temp[time] <= end_date].sort_values(by=tittle, ascending=False).iloc[0][
        time]
    # 将无关的变量删除
    temp.drop(['max2here', 'dd2here'], axis=1, inplace=True)
    results.loc[0, '最大回撤'] = format(max_draw_down, '.2%')
    results.loc[0, '最大回撤开始时间'] = str(start_date)
    results.loc[0, '最大回撤结束时间'] = str(end_date)

    # ===年化收益/回撤比：我个人比较关注的一个指标
    results.loc[0, '年化收益/回撤比'] = round(annual_return / abs(max_draw_down), 2)

    return results.T
