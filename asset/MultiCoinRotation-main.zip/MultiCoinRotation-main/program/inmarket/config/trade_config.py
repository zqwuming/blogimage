import ccxt
from trade.utility import robust
import warnings
warnings.filterwarnings('ignore')  # 屏蔽warning报错
from config.config import settings

# 不参与交易的币种列表
symbol_list = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'UNIUSDT']

# 每次获取k线的数量
LIMIT = 550

# ===其他
long_sleep_time = 20
cheat_seconds = 0

# ===创建交易所
BINANCE_CONFIG = {
    'apiKey': settings.BINANCE_API_KEY,
    'secret': settings.BINANCE_SECRET,
    'timeout': 30000,
    'rateLimit': 10,
    'hostname': 'binancezh.ac',  # 无法fq的时候启用
    'enableRateLimit': False,
    'options': {
        'adjustForTimeDifference': True,
        'recvWindow': 10000,
    },
}

exchange = ccxt.binance(BINANCE_CONFIG)

# ===交易策略列表
strategy_list = [

    # 强者恒强轮动策略
    {
        'hold_period': '24H',  # 持仓周期
        'c_factor': '强者恒强轮动策略',  # 复合因子
        'factors': [
            {
                'factor': 'rotatory',  # 选币时参考的因子
                'para': 480,  # 策略的参数(20天)
                'if_reverse': False,
                'weight': 1.0,
            }
        ],
        'long_weight': 2,
        'short_weight': 0,
        'selected_coin_num': 1,  # 做多或做空币的数量
        'strategy_position': 1,  # 该策略的仓位
        'leverage_rate': 2,  # 该策略的杠杆

    },
    # 强者恒强轮动策略（做空）
    {
        'hold_period': '24H',  # 持仓周期
        'c_factor': '强者恒强轮动策略（做空）',  # 复合因子
        'factors': [
            {
                'factor': 'rotatory_x',  # 选币时参考的因子
                'para': 480,  # 策略的参数(20天)
                'if_reverse': False,
                'weight': 1.0,
            }
        ],
        'long_weight': 0,
        'short_weight': 2,
        'selected_coin_num': 1,  # 做多或做空币的数量
        'strategy_position': 1,  # 该策略的仓位
        'leverage_rate': 2,  # 该策略的杠杆
    },

]
