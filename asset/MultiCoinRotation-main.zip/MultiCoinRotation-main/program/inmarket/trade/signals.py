# -*- coding: utf-8 -*-

# 轮动策略
def signal_rotatory(df, n=480):
    """
    轮动策略：选择n天内涨幅最大的币种
    """
    df['raw_rotatory'] = df['close'].pct_change(n)*(-1)
    df.loc[df['raw_rotatory'] < 0, 'rotatory'] = df['raw_rotatory']
    df.drop(['raw_rotatory'], axis=1, inplace=True)
    return df
    
# 轮动策略(做空)
def signal_rotatory_x(df, n=480):
    """
    轮动策略：选择n天内跌幅最大的币种
    """
    df['raw_rotatory_x'] = df['close'].pct_change(n)
    df.loc[df['raw_rotatory_x'] < 0, 'rotatory_x'] = df['raw_rotatory_x']
    df.drop(['raw_rotatory_x'], axis=1, inplace=True)

    return df

# 轮动中性
def signal_rotatory_neutral(df, n=480):
    """
    轮动策略：选择n天内涨幅最大的币种做多，最小的做空
    """
    df['rotatory_neutral'] = df['close'].pct_change(n)
    return df
