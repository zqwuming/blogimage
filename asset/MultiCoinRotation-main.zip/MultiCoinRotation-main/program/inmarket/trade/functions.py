# -*- coding: utf-8 -*-

import pandas as pd
import numpy as np
import time
import os
from multiprocessing import Pool, cpu_count
from datetime import datetime, timedelta
from config.config import *
from config.trade_config import *
from trade.signals import *
from trade.utility import robust


def cal_strategy_trade_usdt(strategy_list, trade_usdt):
    """
    计算每个策略分配的资金
    :param strategy_list: 策略参数列表
    :param trade_usdt: 可用于交易的资金 * 杠杆倍数
    :return:
    """
    df = pd.DataFrame()

    for strategy in strategy_list:
        c_factor = strategy['c_factor']  # 复合因子名称
        hold_period = strategy['hold_period']  # 持仓时间
        selected_coin_num = strategy['selected_coin_num']  # 选币数量
        strategy_position = strategy['strategy_position']  # 策略仓位
        leverage_rate = strategy['leverage_rate']  # 策略杠杆

        offset_num = int(hold_period[:-1])
        for offset in range(offset_num):
            df.loc[
                f'{c_factor}_{hold_period}_{offset}H', '策略分配资金'] = trade_usdt * strategy_position * leverage_rate / 2 / offset_num / selected_coin_num

    df.reset_index(inplace=True)
    df.rename(columns={'index': 'key'}, inplace=True)

    return df


# =====获取持仓
# 获取币安账户的实际持仓
def update_symbol_info(exchange, symbol_list):
    """
    使用ccxt接口：fapiPrivate_get_positionrisk，获取账户持仓
    返回值案例
                 positionAmt  entryPrice  markPrice  unRealizedProfit  liquidationPrice  ...  maxNotionalValue  marginType isolatedMargin  isAutoAddMargin
    positionSide
    symbol                                                                            ...
    XMRUSDT         0.003    63.86333  63.877630          0.000043             0.000  ...            250000       cross            0.0            false         LONG
    ATOMUSDT       -0.030     2.61000   2.600252          0.000292           447.424  ...             25000       cross            0.0            false        SHORT
    :param exchange:
    :param symbol_list:
    :return:
    """
    # 获取原始数据
    position_risk = robust(exchange.fapiPrivate_get_positionrisk)

    # 将原始数据转化为df
    position_risk = pd.DataFrame(position_risk, dtype='float')

    # 整理数据
    position_risk.rename(columns={'positionAmt': '当前持仓量'}, inplace=True)
    position_risk = position_risk[position_risk['当前持仓量'] != 0]  # 只保留有仓位的币种
    position_risk.set_index('symbol', inplace=True)  # 将symbol设置为index

    # 创建symbol_info
    symbol_info = pd.DataFrame(index=symbol_list, columns=['当前持仓量'])
    symbol_info['当前持仓量'] = position_risk['当前持仓量']
    symbol_info['当前持仓量'].fillna(value=0, inplace=True)

    return symbol_info


def next_run_time(time_interval, ahead_seconds=5, cheat_seconds=100):
    """
        根据time_interval，计算下次运行的时间，下一个整点时刻。
        目前只支持分钟和小时。
        :param time_interval: 运行的周期，15m，1h
        :param ahead_seconds: 预留的目标时间和当前时间的间隙
        :return: 下次运行的时间
        案例：
        15m  当前时间为：12:50:51  返回时间为：13:00:00
        15m  当前时间为：12:39:51  返回时间为：12:45:00
        10m  当前时间为：12:38:51  返回时间为：12:40:00
        5m  当前时间为：12:33:51  返回时间为：12:35:00

        5m  当前时间为：12:34:51  返回时间为：12:40:00

        30m  当前时间为：21日的23:33:51  返回时间为：22日的00:00:00

        30m  当前时间为：14:37:51  返回时间为：14:56:00

        1h  当前时间为：14:37:51  返回时间为：15:00:00

        """
    if time_interval.endswith('m') or time_interval.endswith('h'):
        pass
    elif time_interval.endswith('T'):
        time_interval = time_interval.replace('T', 'm')
    elif time_interval.endswith('H'):
        time_interval = time_interval.replace('H', 'h')
    else:
        print('time_interval格式不符合规范。程序exit')
        exit()

    ti = pd.to_timedelta(time_interval)
    now_time = datetime.now()
    this_midnight = now_time.replace(hour=0, minute=0, second=0, microsecond=0)
    min_step = timedelta(minutes=1)

    target_time = now_time.replace(second=0, microsecond=0)

    while True:
        target_time = target_time + min_step
        delta = target_time - this_midnight
        if delta.seconds % ti.seconds == 0 and (target_time - now_time).seconds >= ahead_seconds:
            # 当符合运行周期，并且目标时间有足够大的余地，默认为60s
            break
    if cheat_seconds > 0.1:
        target_time = target_time - timedelta(seconds=cheat_seconds)
    print('程序下次运行的时间：', target_time, '\n')
    return target_time


def sleep_until_run_time(time_interval, ahead_time=1, if_sleep=True, cheat_seconds=120):
    """
    根据next_run_time()函数计算出下次程序运行的时候，然后sleep至该时间
    :param time_interval:
    :param head_time:
    :param if_sleep:
    :param cheat_seconds:
    :return:
    """
    # 计算下次运行时间
    run_time = next_run_time(time_interval, ahead_time, cheat_seconds)
    # sleep
    if if_sleep:
        time.sleep(max(0, (run_time - datetime.now()).seconds))
        while True:
            if datetime.now() > run_time:
                break
    return run_time


# =====获取数据
# 获取单个币种的1小时数据
def fetch_binance_swap_candle_data(exchange, symbol, run_time, limit):
    """
    通过ccxt的接口fapiPublic_get_klines，获取永续合约k线数据
    获取单个币种的1小时数据
    :param exchange:
    :param symbol:
    :param limit:
    :param run_time:
    :return:
    """
    # print('正在获取'+symbol+'的交易数据')
    # 获取数据
    kline = robust(exchange.fapiPublic_get_klines, {'symbol': symbol, 'interval': '1h', 'limit': limit})

    # 转化为df
    columns = ['candle_begin_time', 'open', 'high', 'low', 'close', 'volume', 'close_time', 'quote_volume', 'trade_num',
               'taker_buy_base_asset_volume', 'taker_buy_quote_asset_volume', 'ignore']
    df = pd.DataFrame(kline, columns=columns, dtype='float')

    # 整理数据
    df['candle_begin_time'] = pd.to_datetime(df['candle_begin_time'], unit='ms') + pd.Timedelta(hours=8)  # 时间转化为东八区
    df['symbol'] = symbol  # 添加symbol列
    columns = ['symbol', 'candle_begin_time', 'open', 'high', 'low', 'close', 'volume', 'quote_volume']
    df = df[columns]

    # 删除runtime那行的数据，如果有的话
    df = df[df['candle_begin_time'] != run_time]

    return symbol, df


def fetch_all_binance_swap_candle_data(exchange, symbol_list, run_time, limit):
    """
     获取所有币种永续合约数据的1小时K线数据
     :param exchange:
     :param symbol_list:
     :param run_time:
     :return:
     """

    # 创建参数列表
    arg_list = [(exchange, symbol, run_time, limit) for symbol in symbol_list]
    start_time = time.time()

    result = []
    for arg in arg_list:
        (exchange, symbol, run_time, limit) = arg
        res = fetch_binance_swap_candle_data(exchange, symbol, run_time, limit)
        result.append(res)

    df = dict(result)
    print('获取所有币种K线数据完成，花费时间：', time.time() - start_time, '\n')
    return df

def append_new_symbol_candle_data_to_new(symbol_candle_data, new_symbol_candle_data):
    for symbol in symbol_list:
        df1 = symbol_candle_data[symbol]
        df2 = new_symbol_candle_data[symbol]
        df = df1.append(df2, ignore_index=True)
        df.drop_duplicates(subset=['candle_begin_time'], keep='first', inplace=True)
        df.sort_values(['candle_begin_time'])
        df = df.iloc[-600:]  # 保持最大K线数量不会超过600个
        df.reset_index(drop=True, inplace=True)
        symbol_candle_data[symbol] = df
        print(df.tail(10))
    return symbol_candle_data



def cal_factor_and_select_coin(strategy_list, symbol_candle_data, run_time):
    '''
    根据因子进行选币
    :param strategy_list:  config.py 中关于因子的配置
    :param symbol_candle_data: 本周期获取到的k线数据
    :param run_time:  本周期时间
    :return: 返回选出的币
    '''

    s_time = time.time()

    select_coin_list = []
    for strategy in strategy_list:
        # 获取策略参数
        c_factor = strategy['c_factor']  # 复合因子名称
        hold_period = strategy['hold_period']
        selected_coin_num = strategy['selected_coin_num']
        factors = strategy['factors']
        long_weight = strategy['long_weight']
        short_weight = strategy['short_weight']

        # ===逐个遍历每一个币种，计算其因子，并且转化周期
        period_df_list = []
        symbol_list = list(symbol_candle_data.keys())

        for symbol in symbol_list:

            # =获取相应币种1h的k线，深度拷贝
            df = symbol_candle_data[symbol].copy()

            df[c_factor] = 0  # 用于计算复合因子的排名

            for factor_dict in factors:
                factor = factor_dict['factor']
                para = factor_dict['para']
                if_reverse = factor_dict['if_reverse']

                df = eval(f'signal_{factor}')(df, int(para))  # 计算信号

                factor_bh = '%s_bh_%d' % (factor, para)

                # 初始化
                df[factor_bh + '_因子'] = np.nan


                if if_reverse:
                    df[factor_bh + '_因子'] = - df[factor]
                else:
                    df[factor_bh + '_因子'] = df[factor]

            # 将数据转化为需要的周期
            df['start_time'] = df['candle_begin_time']
            df['end_time'] = df['candle_begin_time']
            df.set_index('candle_begin_time', inplace=True)
            df = df[-24:]
            # agg_dict = {'symbol': 'first', 'start_time': 'first', 'end_time': 'last', 'close': 'last', c_factor: 'last'}
            #
            # for factor_dict in factors:
            #     factor = factor_dict['factor']
            #     para = factor_dict['para']
            #     factor_bh = '%s_bh_%d' % (factor, para)
            #     agg_dict[factor_bh + '_因子'] = 'last'
            #
            # # 转换生成每个策略所有offset的因子
            # for offset in range(int(hold_period[:-1])):
            #     # 转换周期
            #     period_df = df.resample(hold_period, base=offset).agg(agg_dict)
            #     period_df['offset'] = offset
            #     # 保存策略信息到结果当中
            offset = 0
            for i, row in df.iterrows():

                df.loc[i, 'key'] = f'{c_factor}_{hold_period}_{offset}H'  # 创建主键值
                offset += 1
            #
            #     # 截取指定周期的数据
            #     period_df = period_df[
            #         (period_df['start_time'] <= run_time - timedelta(hours=int(hold_period[:-1]))) &
            #         (period_df['start_time'] > run_time - 2 * timedelta(hours=int(hold_period[:-1])))
            #         ]
            period_df_list.append(df)

        # ===将不同offset的数据，合并到一张表
        df = pd.concat(period_df_list)

        df = df.sort_values(['start_time', 'symbol'])

        # df[c_factor] = 0  # 用于计算复合因子的排名
        #
        # # 计算因子权重并将币种排序
        # for factor_dict in factors:
        #     factor = factor_dict['factor']
        #     weight = factor_dict['weight']
        #     para = factor_dict['para']
        #
        #     factor_bh = '%s_bh_%d' % (factor, para)

        df[factor + '_排名'] = df.groupby('start_time')[factor].rank()
        # df[c_factor] += df[factor_bh + '_排名'] * weight
        # ===选币数据整理完成，接下来开始选币
        # 多空双向rank
        # df['币总数'] = df.groupby(df.index).size()
        # df['rank'] = df.groupby('start_time')[c_factor].rank(method='first')

        # 筛选出需要的币种
        df['方向'] = 0
        if factor == 'rotatory':
            df.loc[(df[factor + '_排名'] <= selected_coin_num), '方向'] = 1 * long_weight
        elif factor == 'rotatory_x':
            df.loc[(df[factor + '_排名'] <= selected_coin_num), '方向'] = -1 * short_weight
        df = df[df['方向'] != 0]
        # ===将每个币种的数据存储到dict中
        # 删除不需要的列
        # df.drop(['币总数', 'rank'], axis=1, inplace=True)
        df.reset_index(inplace=True)
        select_coin_list.append(df)

    select_coin = pd.concat(select_coin_list)
    print('完成选币数据整理 & 选币，花费时间：', time.time() - s_time)
    print(select_coin)
    return select_coin


def place_order(symbol_info, symbol_last_price, min_qty, price_precision):
    '''
    下单函数
    :param symbol_info: 订单信息，这里应用的是拆分后的订单信息
    :param symbol_last_price: 运用fetch_binance_ticker_price函数获取到的ticker信息
    :param min_qty: 最小下单量精度
    :param price_precision: 最小下单价格精度
    :return:
    '''
    for symbol, row, in symbol_info.dropna(subset=['实际下单量']).iterrows():
        if symbol not in min_qty:
            continue

        # 计算下单量，按照最小下单量向下取整
        # 对实际下单量进行四舍五入
        quantity = row['实际下单量']
        quantity = round(quantity, min_qty[symbol])
        reduce_only = np.isnan(row['目标下单份数']) or row['目标下单量'] * quantity < 0

        quantity = abs(quantity)  # 下单量取正数
        if quantity == 0:
            print(symbol, quantity, '实际下单量为0，不下单')
            continue

        # 计算下单方向、价格
        if row['实际下单量'] > 0:
            side = 'BUY'
            price = symbol_last_price[symbol] * 1.02
        else:
            side = 'SELL'
            price = symbol_last_price[symbol] * 0.98

        # 修改最小下单精度
        price = round(price, price_precision[symbol])

        if symbol not in price_precision:
            continue

        if (quantity * price < 50) and not reduce_only:
            print(symbol, '下单量少于50USDT，不下单')
            continue

        # 下单参数
        params = {'symbol': symbol, 'side': side, 'type': 'LIMIT', 'price': price, 'quantity': quantity,
                  'clientOrderId': str(time.time()), 'timeInForce': 'GTC', 'reduceOnly': reduce_only}

        open_order = robust(exchange.fapiPrivate_post_order, params)
        print('下单完成，下单信息：', open_order, '\n')


def twap_place_order(symbol_info, select_coin, strategy_trade_usdt, min_qty, price_precision):
    """

    :param symbol_info: 通过函数update_symbol_info获取到的当前持仓信息
    :param select_coin: 通过函数cal_factor_and_select_coin选出的币
    :param strategy_trade_usdt: 通过函数cal_strategy_trade_usdt计算出的每个策略分配的资金
    :param min_qty: 通过交易所返回的数据，得到的各个币种最小下单量
    :param price_precision: 通过交易所返回的数据，得到的各个币种最小下单精度
    :return:
    """
    # 单次最大下单金额
    Max_one_order_amount = settings.MAX_ONE_ORDER_AMOUNT
    # 订单间隔时间
    Twap_interval = settings.TWAP_INTERVAL
    # 这里使用本文件内的twap_cal_order_amount函数用于整理并计算各个币种的下单量
    symbol_info = twap_cal_order_amount(symbol_info, select_coin, strategy_trade_usdt)
    # 补全历史持仓的最新价格信息
    if symbol_info['实际下单资金'].isnull().any():
        nan_symbol = list(symbol_info.loc[symbol_info['实际下单资金'].isnull()].index)
        symbol_last_price = fetch_binance_ticker_price(exchange, nan_symbol)
        symbol_info.loc[nan_symbol, '实际下单资金'] = symbol_info.loc[nan_symbol, '实际下单量'] * symbol_last_price[nan_symbol]
    # symbol_info.to_csv('symbol_info.csv')
    # symbol_info = pd.read_csv('symbol_info.csv', encoding='gbk', index_col='symbol')  # 调试用
    print('本周期最终下单计划\n', symbol_info)

    # 使用twap算法拆分订单
    twap_symbol_info_list = get_twap_symbol_info_list(symbol_info, Max_one_order_amount)

    # 对拆分后的订单列表进行分批下单
    for i in range(len(twap_symbol_info_list)):

        # ===获取币种最新价格
        symbol_list = list(twap_symbol_info_list[i].index)
        symbol_last_price = fetch_binance_ticker_price(exchange, symbol_list)

        # ===逐批下单
        place_order(twap_symbol_info_list[i], symbol_last_price, min_qty, price_precision)

        if i < len(twap_symbol_info_list) - 1:
            print(f'Twap {Twap_interval} s后下单。')
            time.sleep(Twap_interval)


def fetch_binance_ticker_price(binance, symbol_list):
    '''
    获取ticker数据补全信息
    tickers['price']实例：
        symbol
        BTCUSDT    45541.73
    :param binance:
    :param nan_symbol:
    :return:
    '''
    ticker_df_list = []
    for i in range(len(symbol_list)):
        symbol = symbol_list[i]
        ticker = robust(binance.fapiPublic_get_ticker_price, {'symbol': symbol})
        ticker_df_list.append(ticker)
    tickers = pd.DataFrame(ticker_df_list, dtype=float)
    tickers.set_index('symbol', inplace=True)
    return tickers['price']


# 增加了数据,供后续TWAP使用
def twap_cal_order_amount(symbol_info, select_coin, strategy_trade_usdt):
    """
    整理并计算各个币种的下单量
    :param symbol_info: 通过函数update_symbol_info获取到的当前持仓信息
    :param select_coin: 通过函数cal_factor_and_select_coin选出的币
    :param strategy_trade_usdt: 通过函数cal_strategy_trade_usdt计算出的每个策略分配的资金
    :return: 整理后的symbol_info，带有各个要下单币种的实际下单量
    """
    # 将选出的币与每个策略分配的资金合并成一个dataframe，并计算出每个币种的下单量
    select_coin = pd.merge(left=select_coin, right=strategy_trade_usdt, how='left').fillna(0)
    select_coin['目标下单量'] = select_coin['策略分配资金'] / select_coin['close'] * select_coin['方向']

    # 对下单量进行汇总
    symbol_info['目标下单量'] = select_coin.groupby('symbol')[['目标下单量']].sum()
    symbol_info['目标下单量'].fillna(value=0, inplace=True)
    symbol_info['目标下单份数'] = select_coin.groupby('symbol')[['方向']].sum()
    symbol_info['实际下单量'] = symbol_info['目标下单量'] - symbol_info['当前持仓量']
    select_coin.sort_values('start_time', inplace=True)
    symbol_info['close'] = select_coin.groupby('symbol')[['close']].last()
    symbol_info['实际下单资金'] = symbol_info['实际下单量'] * symbol_info['close']
    del symbol_info['close']

    # 删除实际下单量为0的币种
    symbol_info = symbol_info[symbol_info['实际下单量'] != 0]
    return symbol_info


def get_twap_symbol_info_list(symbol_info, Max_one_order_amount):
    '''
    对超额订单进行拆分，并进行调整，尽可能每批订单多空平衡
    :param symbol_info: 原始下单信息
    :param Max_one_order_amount:  单次下单最大金额
    :return:拆分后的symbol_info,实例如下
    [
              当前持仓量 目标下单量 目标下单份数    实际下单量  实际下单资金  下单金额排名
    symbol
    ETHUSDT     0.0     0.228944  3.434652     0.228944  720.000000     1.0
    LTCUSDT     0.0    -4.334738 -2.879792    -4.334738 -720.000000     1.0
    LINKUSDT    0.0    29.683377  3.283925    29.683377  720.000000     2.0
    XLMUSDT     0.0 -2482.245625 -3.000000 -2482.245625 -752.145247     2.0
    TRXUSDT     0.0  9740.259744  2.880161  9740.259744  720.000000     3.0
    BTCUSDT     0.0     0.005500  1.000000     0.005500  249.935249     4.0
    ,
                当前持仓量 目标下单量 目标下单份数   实际下单量  实际下单资金  下单金额排名
    symbol
    ETHUSDT     0.0     0.228944  3.434652     0.228944  720.000000     1.0
    LTCUSDT     0.0    -1.686167 -1.120208    -1.686167 -280.072271     1.0
    LINKUSDT    0.0    29.683377  3.283925    29.683377  720.000000     2.0
    TRXUSDT     0.0  3787.120496  1.119839  3787.120496  279.943947     3.0
    ,
                当前持仓量 目标下单量 目标下单份数   实际下单量  实际下单资金  下单金额排名
    symbol
    ETHUSDT     0.0   0.228944  3.434652   0.228944  720.000000     1.0
    LINKUSDT    0.0  12.945185  1.432149  12.945185  313.998411     2.0
    ,
                当前持仓量 目标下单量 目标下单份数   实际下单量  实际下单资金  下单金额排名
    symbol
    ETHUSDT    0.0  0.228944  3.434652  0.228944   720.0     1.0
    ,
                当前持仓量 目标下单量 目标下单份数   实际下单量  实际下单资金  下单金额排名
    symbol
    ETHUSDT    0.0  0.052271  0.784176  0.052271  164.38537     1.0
    ]
    '''

    long = symbol_info[symbol_info['实际下单量'] >= 0]
    short = symbol_info[symbol_info['实际下单量'] < 0]

    long['下单金额排名'] = long['实际下单资金'].rank(ascending=False, method='first')
    short['下单金额排名'] = short['实际下单资金'].rank(method='first')
    symbol_info = pd.concat([long, short]).sort_values(['下单金额排名', '实际下单资金'], ascending=[True, False])

    # 复制信息并创建一个列表，用于存放拆分后每次下单的信息，拆分后效果如下：
    # 如初始eth2000刀，btc1000刀，ltc500刀，拆分后为
    # 1.eth720 btc720 ltc500
    # 2.eth720 btc280 ltc0
    # 3.eth560 btc0 ltc0
    twap_symbol_info_list = [symbol_info.copy()]
    num = 0  # 计数

    is_twap = True if max(abs(symbol_info['实际下单资金'])) > Max_one_order_amount else False  # 判断是否超过最大下单金额
    safe_amount = 0.1 * Max_one_order_amount
    while is_twap:
        symbol_info = twap_symbol_info_list[num]
        add_order_list = []
        for i in range(symbol_info.shape[0]):
            order = symbol_info.iloc[i:i + 1]  # 获取symbol所在列的数据
            if abs(order.iat[0, 4]) > Max_one_order_amount:  # 判断实际下单资金是否大于最大单笔下单金额
                ratio = (Max_one_order_amount - safe_amount) / abs(order.iat[0, 4])  # 计算最大单笔下单金额占实际下单资金的比率
                add_order = order.copy()
                add_order[['当前持仓量', '目标下单量', '目标下单份数', '实际下单量', '实际下单资金']] = add_order[
                                                                                 ['当前持仓量', '目标下单量', '目标下单份数', '实际下单量',
                                                                                  '实际下单资金']] * (1 - ratio)
                symbol_info.iloc[i, :-1] = symbol_info.iloc[i, :-1] * ratio  # 按比例计算i列的单次下单金额等
                add_order_list.append(add_order)
        add_df = pd.concat(add_order_list)  # add_df为下完本次单后剩余没有下完的单
        twap_symbol_info_list[num] = symbol_info.copy()
        twap_symbol_info_list.append(add_df.copy())
        is_twap = True if max(abs(add_df['实际下单资金'])) > Max_one_order_amount else False
        num += 1
    print(f'Twap分{len(twap_symbol_info_list)}次下单\n')

    # 以下代码块主要功能为调整不同批次间的多空平衡问题，资金量不是特别大的老板可以注释掉
    # '''*******************************************************************************'''
    # bl = []
    # for x in twap_symbol_info_list:
    #     bl.append([round(abs(x['实际下单资金']).sum(), 1), round(x['实际下单资金'].sum(), 1)])
    # _summary_df = pd.DataFrame(bl, columns=['下单金额', '多空失衡金额'])
    # print(_summary_df, '\n')
    # print(_summary_df.sum())
    # is_adjust = False
    # for j in range(len(twap_symbol_info_list)):
    #     adjust_df = pd.DataFrame()
    #     main_order_df = twap_symbol_info_list[j].copy()
    #     for i in range(5, 25, 1):
    #         if abs(main_order_df.iloc[:int(len(main_order_df) * (i - 2) / i)]['实际下单资金'].sum()) > 1000:
    #             adjust_df = main_order_df.iloc[int(len(main_order_df) * (i - 2) / i):]
    #             main_order_df = main_order_df.iloc[:int(len(main_order_df) * (i - 2) / i)]
    #             print((i - 2) / i, f'\n第 {j + 1} 批twap订单需要调整\n')
    #             is_adjust = True
    #             twap_symbol_info_list[j] = main_order_df.copy()
    #             break
    #         else:
    #             continue
    #     else:
    #         pass
    #         # twap订单无需调整
    #
    #     for i in range(adjust_df.shape[0]):
    #         temp = [x['实际下单资金'].sum() for x in twap_symbol_info_list[j + 1:]]
    #         max_ind = temp.index(max(temp))
    #         min_ind = temp.index(min(temp))
    #         if adjust_df.iat[i, 4] < 0:
    #             twap_symbol_info_list[max_ind + j + 1] = twap_symbol_info_list[max_ind + j + 1].append(
    #                 adjust_df.iloc[i:i + 1])
    #         else:
    #             twap_symbol_info_list[min_ind + j + 1] = twap_symbol_info_list[min_ind + j + 1].append(
    #                 adjust_df.iloc[i:i + 1])
    #
    # if is_adjust:
    #     bl = []
    #     for x in twap_symbol_info_list:
    #         bl.append([round(abs(x['实际下单资金']).sum(), 1), round(x['实际下单资金'].sum(), 1)])
    #     summary_df = pd.DataFrame(bl, columns=['下单金额', '多空失衡金额'])
    #     print(summary_df, '\n')
    #     print(summary_df.sum())
    # '''*******************************************************************************'''

    # 判断是否多空平衡，如果有只做多或者只做空的策略可以注释掉
    # all_df = pd.concat(twap_symbol_info_list)
    # try:
    #     assert abs(all_df['目标下单份数'].sum()) < 1e-6
    # except Exception as e:
    #     print('多空不平衡，Twap订单生产出错')
    #     send_dingding_msg('多空不平衡，Twap订单生产出错： %s'%str(e))

    return twap_symbol_info_list



def get_spot_balance(exchange, asset):
    '''
    获取现货账户资产信息
    :param exchange:
    :param asset: 资产名
    :return: 资产数量
    '''
    account = robust(exchange.private_get_account, )
    balance = account['balances']
    balance = pd.DataFrame(balance)
    # 如果子账号没有使用过现货账户，此处会返回空值
    if balance.empty:
        return 0.0
    amount = float(balance[balance['asset'] == asset]['free'])
    print(f'查询到现货账户有{amount} {asset}')
    return amount


def spot_buy_quote(exchange, symbol, quote_amount):
    info = robust(exchange.privatePostOrder, {
        'symbol': symbol,
        'side': 'BUY',
        'type': 'MARKET',
        'quoteOrderQty': quote_amount
    })
    print(f'市价买入{symbol}成功: {info}')
def transfer_future_to_spot(exchange, asset, amount):
    info = robust(exchange.sapiPostFuturesTransfer, {
        'type': 2,  # 1：现货至u本位合约；2：u本位合约至现货
        'asset': asset,
        'amount': amount,
    })
    print(f'从U本位合约至现货账户划转成功：{info}，划转数量：{amount} {asset}，时间：{datetime.now()}')


def transfer_spot_to_future(exchange, asset, amount):
    info = robust(exchange.sapiPostFuturesTransfer, {
        'type': 1,  # 1：现货至u本位合约；2：u本位合约至现货
        'asset': asset,
        'amount': amount,
    })
    print(f'从现货至U本位合约账户划转{amount} {asset}成功：{info}，时间：{datetime.now()}')


def replenish_bnb(exchange, BNB_use_to_burn, min_BNB_use_to_burn):
    print('可供燃烧的BNB：', BNB_use_to_burn)
    if BNB_use_to_burn < min_BNB_use_to_burn:
        spot_BNB_amount = get_spot_balance(exchange, 'BNB')
        print(f"当前现货账户持有BNB:{spot_BNB_amount} ")
        if spot_BNB_amount < 0.01:
            print("从现货市场买入10 USDT等值BNB并转入合约账户")
            spot_usdt_amount = get_spot_balance(exchange, 'USDT')
            if spot_usdt_amount < 10:
                transfer_future_to_spot(exchange, 'USDT', 10.01 - spot_usdt_amount)
            spot_buy_quote(exchange, 'BNBUSDT', 10)
            time.sleep(2)
            spot_bnb_amount_new = get_spot_balance(exchange, 'BNB')
            transfer_spot_to_future(exchange, 'BNB', spot_bnb_amount_new)
            message = f"成功买入BNB并转入U本位合约账户{spot_bnb_amount_new}个"
            print(message)
        else:
            transfer_spot_to_future(exchange, 'BNB', spot_BNB_amount)
            print(f'把已有{spot_BNB_amount}个BNB转入合约账户')


# 用于生成文件夹路径
def creat_folders(*args):
    abs_path = os.path.abspath(os.path.join(*args))
    if not os.path.exists(abs_path):
        os.makedirs(abs_path)
    return abs_path            

# 用于保存每个策略的选币结果，debug模式的单独保存，正常模式的append到已有csv文件中
def save_select_coin(select_coin, debug = False):
    _ = os.path.abspath(os.path.dirname(__file__))  # 返回当前文件路径
    path_root_out = creat_folders(_, os.pardir, os.pardir,os.pardir, 'data','select_coin')

    select_coin['c_factor'] = select_coin['key'].apply(lambda x: '_'.join(x.split('_')[:-2]))
    select_coin['hold_hour'] = select_coin['key'].apply(lambda x: x.split('_')[-2])

    for (c_factor, hold_hour), select_coin_ in select_coin.groupby(['c_factor', 'hold_hour']):
        # columns_list = list(set(c for c in select_coin_.columns if '_bh_' not in c))
        # print(select_coin_[columns_list])
        print(f'\n{c_factor}_{hold_hour}')
        c_factor_select_coin = pd.DataFrame()
        c_factor_select_coin[['做多币种', '做多权重', '做空币种','做空权重']] = np.nan
        c_factor_select_coin['做多币种'] = select_coin_[select_coin_['方向'] > 0].groupby('tail_time')['symbol'].sum()
        c_factor_select_coin['做多权重'] = select_coin_[select_coin_['方向'] > 0].groupby('tail_time')['方向'].mean()
        c_factor_select_coin['做空币种'] = select_coin_[select_coin_['方向'] < 0].groupby('tail_time')['symbol'].sum()
        c_factor_select_coin['做空权重'] = select_coin_[select_coin_['方向'] < 0].groupby('tail_time')['方向'].mean()


        path_out = f'{path_root_out}/{c_factor}_{hold_hour}.csv'
        print(c_factor_select_coin)

        # debug模式下，选币数据单独保存以免污染整点选币数据
        if debug:
            # c_factor_select_coin.to_csv(path_out.replace('.csv','_debug.csv'))
            c_factor_select_coin.to_csv(f'{path_root_out}/debug_{c_factor}_{hold_hour}.csv')
        # 非debug模式，选币数据连续保存到同一个文件中
        else:
            # 如果文件已存在，读取→合并
            if os.path.exists(path_out):
                c_factor_select_coin0 = pd.read_csv(path_out, index_col=0)
                if len(c_factor_select_coin0)>1:
                    c_factor_select_coin = pd.concat([c_factor_select_coin0, c_factor_select_coin], axis=0, ignore_index=False)
                    c_factor_select_coin.reset_index(inplace=True)
                    c_factor_select_coin = c_factor_select_coin.drop_duplicates()
                    c_factor_select_coin.set_index('tail_time', drop=True, inplace=True)
            c_factor_select_coin.to_csv(path_out)
