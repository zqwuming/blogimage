# -*- coding: utf-8 -*-

from config.trade_config import *
from config.config import *
from trade.signals import *
from trade.functions import *
from  trade.utility import *
from apscheduler.schedulers.blocking import BlockingScheduler
import math

pd.options.mode.chained_assignment = None
pd.set_option('expand_frame_repr', False)  # 当列太多时不换行

def transation():

    balance = robust(exchange.fapiPrivate_get_balance,)  # 获取账户净值
    balance = pd.DataFrame(balance)
    trade_usdt = float(balance[balance['asset'] == 'USDT']['balance'])
    BNB_use_to_burn = float(balance[balance['asset'] == 'BNB']['balance'].iloc[0])
    print('trade_usdt', trade_usdt)

    # =====获取每个策略分配的资金：固定资金，之后的版本会改成浮动
    strategy_trade_usdt = cal_strategy_trade_usdt(strategy_list, trade_usdt)
    print(strategy_trade_usdt, '\n')

    # 全部处理完，更新k线
    exchange_info = robust(exchange.fapiPublic_get_exchangeinfo,)  # 获取账户净值

    # ===从exchange_info中获取每个币种最小交易量
    min_qty = {x['symbol']: int(math.log(
        float(x['filters'][1]['minQty']), 0.1)) for x in exchange_info['symbols']}
    # 案例：{'BTCUSDT': 3, 'ETHUSDT': 3, 'BCHUSDT': 3, 'XRPUSDT': 1, 'EOSUSDT': 1, 'LTCUSDT': 3, 'TRXUSDT': 0}

    # ===从exchange_info中获取每个币种下单精度
    price_precision = {x['symbol']: int(math.log(
        float(x['filters'][0]['tickSize']), 0.1)) for x in exchange_info['symbols']}
    # 案例：{'BTCUSDT': 2, 'ETHUSDT': 2, 'BCHUSDT': 2, 'XRPUSDT': 4, 'EOSUSDT': 3, 'LTCUSDT': 2, 'TRXUSDT': 5, 'ETCUSDT': 3}

    # =====获取账户的实际持仓
    symbol_info = update_symbol_info(exchange, symbol_list)
    print(symbol_info.T, '\n')

    run_time = datetime.now().replace(minute=0, second=0, microsecond=0) 
    if (run_time.hour % 8 == 0):
        print('\n', '每日结算时间', '\n\n')
        time.sleep(60)

    # =====并行获取所有币种的1小时K线
    symbol_candle_data = fetch_all_binance_swap_candle_data(exchange, symbol_list, run_time,limit=550)
    print(symbol_candle_data['BTCUSDT'].tail(2), '\n')

    # =====选币数据整理 & 选币
    select_coin = cal_factor_and_select_coin(strategy_list, symbol_candle_data, run_time)

    # ===== 保存选币数据
    #save_select_coin(select_coin) 

    twap_place_order(symbol_info, select_coin,strategy_trade_usdt, min_qty, price_precision)

    replenish_bnb(exchange, BNB_use_to_burn, settings.MIN_BNB_USE_BURN)



if __name__ == '__main__':
   scheduler = BlockingScheduler()
   scheduler.add_job(transation,'cron',hour='*',id = 'transation') 
   #scheduler.add_job(transation,'cron',minute='*/3',id = 'transation') 

   scheduler.start()
                    
