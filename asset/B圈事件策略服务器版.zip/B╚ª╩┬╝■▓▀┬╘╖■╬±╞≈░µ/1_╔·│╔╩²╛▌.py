# coding=utf8
import pandas as pd
import os
from datetime import timedelta
from DataConfig import *

pd.set_option('expand_frame_repr', False)  # 当列太多时显示完整
file_location = root_path + '/B圈事件策略服务器版/coin_database/binance/spot'

symbol_name = symbol_name
for i in symbol_name:
    # 批量读取文件名称
    file_list = []
    for root, dirs, files in os.walk(file_location):
        for filename in files:
            if filename.startswith(i):
                file_path = os.path.join(root, filename)
                file_path = os.path.abspath(file_path)
                file_list.append(file_path)
                print(file_path)

    # 遍历文件名，批量导入数据
    data = pd.DataFrame()
    for fp in sorted(file_list)[:]:
        df = pd.read_csv(fp, encoding='gbk')
        df['symbol'] = i
        df['candle_begin_time'] = pd.to_datetime(df['candle_begin_time'])
        data = data.append(df, ignore_index=True)  # 注意此时若一下子导入很多文件，可能会内存溢出
        print(data)
    data.reset_index(drop=False, inplace=False)
    print(data)
    data.to_csv(root_path + '/B圈事件策略服务器版/data/Coin/swap_candle/%s.csv' % i, mode='w')