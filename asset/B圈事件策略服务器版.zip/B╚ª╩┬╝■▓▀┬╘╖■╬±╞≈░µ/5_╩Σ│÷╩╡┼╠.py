#coding : utf8
"""
2022  币圈基础事件策略实盘输出 | 邢不行
author: allensrj
"""
import pandas as pd
from Config import *
from Function import *
pd.set_option('display.max_rows', 1000)
pd.set_option('expand_frame_repr', False)  # 当列太多时不换行
# 设置命令行输出时的列对齐功能
pd.set_option('display.unicode.ambiguous_as_wide', True)
pd.set_option('display.unicode.east_asian_width', True)

df = pd.read_pickle(root_path + '/B圈事件策略服务器版/data/事件策略event合集/%s.pkl' % event.split('_')[0])
df = df[['事件日期', 'symbol', event]]
df = df.dropna(how = 'any')
df = df[df['事件日期'] == date_end]
print(df)

# 发送钉钉
content = str(df)
send_dingding_msg(content, robot_id='',
                              secret='')