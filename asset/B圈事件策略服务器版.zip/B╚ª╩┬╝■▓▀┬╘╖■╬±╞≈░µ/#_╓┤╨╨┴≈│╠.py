# coding=utf8

import os
from Function import *

time_interval = '12h'

def main():
    while True:
        run_time = sleep_until_run_time(time_interval, if_sleep=True)

        # 执行流程
        os.system('python 0_获取数据流程.py')
        os.system('python 1_生成数据.py')
        os.system('python 2_计算因子.py')
        os.system('python 3_事件生成.py')
        os.system('python 4_合并数据.py')
        os.system('python 5_输出实盘.py')

        print('\n', '-' * 40, '本次循环结束，%d秒后进入下一次循环' % long_sleep_time, '-' * 40, '\n\n')
        time.sleep(long_sleep_time)

if __name__ == '__main__':
    while True:
        try:
            main()
        except Exception as e:
            print('系统出错，10s之后重新运行，出错原因：' + str(e))
            time.sleep(long_sleep_time)