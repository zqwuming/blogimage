"""
2022  币圈基础事件策略 | 邢不行
author: 邢不行
微信: xbx9585
"""

import pandas as pd
import os
import numpy as np
from Config import root_path, rul_type, candle_type
from glob import glob
import ccxt
import time
from datetime import datetime, timedelta
import datetime
import json
import requests
import hmac
import hashlib
import base64
from urllib import parse

pd.set_option('expand_frame_repr', False)  # 当列太多时不换行
pd.set_option('display.max_rows', 5000)  # 最多显示数据的行数


# region 文件交互
def get_code_list_in_one_dir(path, end_with='csv'):
    """
    从指定文件夹下，导入所有数字货币数据
    :param path:
    :param end_with:
    :return:
    """
    symbol_list = []

    # 系统自带函数os.walk，用于遍历文件夹中的所有文件
    for root, dirs, files in os.walk(path):
        if files:  # 当files不为空的时候
            for f in files:
                if f.endswith(end_with):
                    symbol_list.append(os.path.join(root, f))

    return sorted(symbol_list)


def read_factor(df, factor_list):
    """
    读取需要的因子数据
    :param df:
    :param factor_list:
    :param candle_type:
    :return:
    """
    # 根据strategy_config_list内设置的因子读取
    for factor in factor_list:

        # 遍历所有需要的因子文件
        path_list = glob(root_path + '/B圈事件策略服务器版/data/数据整理/因子数据/%s/%s/*_%s.pkl' % (factor, rul_type, candle_type))
        if len(path_list) == 0:
            print('未获取到因子的数据，请检查因子%s是否存在！！' % factor)
            exit()

        # 遍历文件
        for path in path_list:
            # 读取因子数据
            df_ = pd.read_pickle(path)
            if df.shape[0] != df_.shape[0]:
                print('base数据与因子数据长度不一致，请检查数据是否有误')
                exit()
            # 遍历所有列并合并
            for f in df_.columns:
                df[f] = df_[f]  # 直接根据index合并即可

    return df


def load_rank_factor(df, factor):
    base_df = pd.read_pickle(root_path + '/B圈事件策略服务器版/data/数据整理/因子数据/base_%s_%s.pkl' % (rul_type, candle_type))
    base_df = read_factor(base_df, [factor])
    factor_cols = [col for col in base_df.columns if factor in col]
    base_df = base_df[['candle_begin_time', 'symbol'] + factor_cols]
    # 使用上一个周期的因子数据排名
    base_df[factor_cols] = base_df.groupby('symbol')[factor_cols].shift()
    df = pd.merge(left=df, right=base_df, on=['candle_begin_time', 'symbol'], how='left')
    return df


def cal_net_value(data, margin_rate, event, lvg):
    """
    1、将涨跌幅转为净值
    2、处理爆仓的数据，发生爆仓后，净值为0，由于此处净值为计算交易费用，所以建议适当提高一点维持保证金比例
    :param data: 输入的数据
    :param margin_rate: 保证金率
    :param event: 事件，1表示做多，-1表示做空
    :param lvg: 杠杆倍数。
    :return:
    """
    if data[event] > 0:
        net_value = np.cumprod((np.array(data['未来N周期涨跌幅']) * lvg) + 1)
    elif data[event] < 0:
        net_value = 2 - np.cumprod(1 + (np.array(data['未来N周期涨跌幅']) * lvg))
    inx = np.argwhere(np.array(net_value) < margin_rate)
    if len(inx) > 0:
        first_inx = inx[0][0]
        net_value[first_inx:] = 0
    return list(net_value)


# 导入BTC
def import_benchmark_data(path, rul_type, start, end):
    """
    导入原始一小时数据并转换数据周期，如果是一小时的数据不进行数据周期转换
    :param rul_type: 时间周期
    :param start: 回测开始时间
    :param end: 回测结束时间
    :param path:
    :return:
    """
    # 导入业绩比较基准 （币种）
    benchmark_coin = pd.read_csv(path, encoding='gbk', parse_dates=['candle_begin_time'])

    # 转换数据到指定的周期。可能会从1小时转为1小时，不影响结果。
    agg_dict = {'open': 'first', 'close': 'last', 'volume': 'sum'}
    benchmark_coin = benchmark_coin.resample(rul_type, on='candle_begin_time').agg(agg_dict)

    # 生成指定时间周期的完整时间序列
    benchmark = pd.DataFrame(pd.date_range(start=start, end=end, freq=rul_type), columns=['candle_begin_time'])

    # 将业绩比较基准与时间序列合并
    benchmark = pd.merge(left=benchmark, right=benchmark_coin, on='candle_begin_time', how='left', sort=True)

    # 填充空值
    benchmark['close'].fillna(method='ffill', inplace=True)
    benchmark['open'].fillna(value=benchmark['close'], inplace=True)
    benchmark['volume'].fillna(value=0, inplace=True)
    benchmark['基准涨跌幅'] = benchmark['close'].pct_change()
    benchmark['基准涨跌幅'].fillna(value=benchmark['close'] / benchmark['open'] - 1, inplace=True)  # 第一天的涨跌幅
    benchmark.rename(columns={'volume': '基准成交量'}, inplace=True)

    # 只保留需要的数据
    benchmark = benchmark[['candle_begin_time', '基准涨跌幅', '基准成交量']]
    benchmark.reset_index(inplace=True, drop=True)

    return benchmark


# 将现货数据和BTC数据合并
def merge_with_benchmark(df, benchmark):
    """
    防止数字货币有停牌，选择BTC去补充
    :param df: 币种数据
    :param benchmark: BTC数据
    :return:
    """

    end = df['candle_begin_time'].max()  # 币种k线结束事件

    # ===将现货数据和benchmark数据合并，并且排序
    df = pd.merge(left=df, right=benchmark, on='candle_begin_time', how='right', sort=True, indicator=True)

    # ===对开、高、收、低、前收盘价价格进行补全处理
    # 用前一个周期的收盘价，补全收盘价的空值
    df['close'].fillna(method='ffill', inplace=True)
    # 用收盘价补全开盘价、最高价、最低价的空值
    df['open'].fillna(value=df['close'], inplace=True)
    df['high'].fillna(value=df['close'], inplace=True)
    df['low'].fillna(value=df['close'], inplace=True)

    # ===将停盘时间的某些列，数据填补为0
    fill_0_list = ['volume']
    df.loc[:, fill_0_list] = df[fill_0_list].fillna(value=0)

    # ===用前一个周期的数据，补全其余空值
    df.fillna(method='ffill', inplace=True)

    # ===删除该币种还未上市的日期
    df.dropna(subset=['symbol'], inplace=True)

    # ===判断计算当前周期是否交易
    df['是否交易'] = 1
    df.loc[df['_merge'] == 'right_only', '是否交易'] = 0

    # 删除币种退市之后的数据
    df = df[df['candle_begin_time'] <= end]

    # 删除不需要的字段
    df.drop(labels=['_merge', '基准涨跌幅', '基准成交量'], axis=1, inplace=True)

    df.reset_index(drop=True, inplace=True)

    return df


# endregion


# endregion

def cal_toperiod_symbol_cap_line(data, hold_period, ret_len=30):
    """
    当前周期买入若干个币种，计算买入这些币种之后的资金曲线
    :param data:
    :param hold_period:
    :param ret_len:
    :return:
    """

    # 补全净值不足的币种
    for i in data.index:
        _len = len(data[i])
        if _len < ret_len:
            data[i] = data[i] + [data[i][-1]] * (ret_len - _len)
        elif _len > ret_len:
            data[i] = data[i][:ret_len]

    # 将涨跌幅数据转换成numpy的array格式
    array = np.array(data.tolist(), dtype=object)
    # 获取持仓周期数
    future_period = len(array[0])
    hold_period = min(hold_period, future_period)
    # 截取涨跌幅数据
    array = array[:, :hold_period]  # 行全选，列只选取前hold_period列
    # 计算整体资金曲线
    array = array.mean(axis=0)
    # 判断是否存在0的情况，即爆仓
    ins = np.argwhere(array == 0)
    # 判断如果有爆仓的情况，只取到爆仓的周期
    if len(ins) != 0:
        array = array[:ins[0][0] + 1]

    return list(array)


def update_df(toperiod_event, start_index, cap_num, cap):
    """
    :param toperiod_event:  当前周期的事件数据
    :param start_index:  开始的index，为update使用
    :param cap_num:  使用哪一份资金进行投资
    :param cap:  投资金额是多少
    :return:
    """
    # 获取持仓每周期净值
    value_list = toperiod_event.iloc[0]['持仓每周期净值']

    # 创建用来更新的df
    index = range(start_index, start_index + len(value_list))
    df = pd.DataFrame(index=index)

    # 给更新的df赋值
    df['%s_资金' % cap_num] = value_list
    df['%s_资金' % cap_num] *= cap

    # 判断投入资金是否为0，如果是0证明没钱买入，就全部赋值为空
    if cap == 0:
        df['%s_币种' % cap_num] = None
        df['%s_余数' % cap_num] = 0
    else:
        df['%s_币种' % cap_num] = toperiod_event.iloc[0]['买入币种']
        df['%s_余数' % cap_num] = range(len(value_list), 0, -1)

    return df


def filter_events(df, filter_info):
    """
    根据规则删除不交易的币种
    :param df:
    :param filter_info:
    :return:
    """
    df['keep'] = True
    for k, v in filter_info.items():
        for i in v:
            df.loc[df[k].str.contains(i), 'keep'] = False

    # 只保留需要保留的数据
    df = df[df['keep'] == True]
    del df['keep']
    return df


# 获取数据函数
def save_spot_candle_data_from_exchange(exchange, symbol, time_interval, start_time, path):
    """
    将某个交易所在指定日期指定交易对的K线数据，保存到指定文件夹
    :param exchange: ccxt交易所
    :param symbol: 指定交易对，例如'BTC/USDT'
    :param time_interval: K线的时间周期
    :param start_time: 指定日期，格式为'2020-03-16 00:00:00'
    :param path: 文件保存根目录
    :return:
    """

    # ===对火币的limit做特殊处理
    limit = None
    if exchange.id == 'huobipro':
        limit = 2000

    # ===开始抓取数据
    df_list = []
    start_time_since = exchange.parse8601(start_time)
    end_time = pd.to_datetime(start_time) + datetime.timedelta(days=1)

    while True:
        # 获取数据
        df = exchange.fetch_ohlcv(symbol=symbol, timeframe=time_interval, since=start_time_since, limit=limit)
        # 整理数据
        df = pd.DataFrame(df, dtype=float)  # 将数据转换为dataframe
        # 合并数据
        df_list.append(df)
        # 新的since
        t = pd.to_datetime(df.iloc[-1][0], unit='ms')
        start_time_since = exchange.parse8601(str(t))
        # 判断是否挑出循环
        if t >= end_time or df.shape[0] <= 1:
            break
        # 抓取间隔需要暂停2s，防止抓取过于频繁
        time.sleep(1)

    # ===合并整理数据
    df = pd.concat(df_list, ignore_index=True)
    df.rename(columns={0: 'MTS', 1: 'open', 2: 'high',
                       3: 'low', 4: 'close', 5: 'volume'}, inplace=True)  # 重命名
    df['candle_begin_time'] = pd.to_datetime(df['MTS'], unit='ms')  # 整理时间
    df['candle_begin_time'] = df['candle_begin_time']
    df = df[['candle_begin_time', 'open', 'high', 'low', 'close', 'volume']]  # 整理列的顺序

    # 选取数据时间段
    df = df[df['candle_begin_time'].dt.date == pd.to_datetime(start_time).date()]
    # 去重、排序
    df.drop_duplicates(subset=['candle_begin_time'], keep='last', inplace=True)
    df.sort_values('candle_begin_time', inplace=True)
    df.reset_index(drop=True, inplace=True)

    # ===保存数据到文件
    # 创建交易所文件夹
    path = os.path.join(path, exchange.id)
    if os.path.exists(path) is False:
        os.mkdir(path)
    # 创建spot文件夹
    path = os.path.join(path, 'spot')
    if os.path.exists(path) is False:
        os.mkdir(path)
    # 创建日期文件夹
    path = os.path.join(path, str(pd.to_datetime(start_time).date()))
    if os.path.exists(path) is False:
        os.mkdir(path)
    # 拼接文件目录
    file_name = '_'.join([symbol.replace('/', '-'), time_interval]) + '.csv'
    path = os.path.join(path, file_name)
    # 保存数据
    df.to_csv(path, index=False)


# ===发送钉钉相关函数
# 计算钉钉时间戳
def cal_timestamp_sign(secret):
    # 根据钉钉开发文档，修改推送消息的安全设置https://ding-doc.dingtalk.com/doc#/serverapi2/qf2nxq
    # 也就是根据这个方法，不只是要有robot_id，还要有secret
    # 当前时间戳，单位是毫秒，与请求调用时间误差不能超过1小时
    # python3用int取整
    timestamp = int(round(time.time() * 1000))
    # 密钥，机器人安全设置页面，加签一栏下面显示的SEC开头的字符串
    secret_enc = bytes(secret.encode('utf-8'))
    string_to_sign = '{}\n{}'.format(timestamp, secret)
    string_to_sign_enc = bytes(string_to_sign.encode('utf-8'))
    hmac_code = hmac.new(secret_enc, string_to_sign_enc, digestmod=hashlib.sha256).digest()
    # 得到最终的签名值
    sign = parse.quote_plus(base64.b64encode(hmac_code))
    return str(timestamp), str(sign)


# 发送钉钉消息
def send_dingding_msg(content, robot_id='',
                      secret=''):
    """
    :param content:
    :param robot_id:  你的access_token，即webhook地址中那段access_token。例如如下地址：https://oapi.dingtalk.com/robot/
n    :param secret: 你的secret，即安全设置加签当中的那个密钥
    :return:
    """
    try:
        msg = {
            "msgtype": "text",
            "text": {"content": content + '\n' + datetime.datetime.now().strftime("%m-%d %H:%M:%S")}}
        headers = {"Content-Type": "application/json;charset=utf-8"}
        # https://oapi.dingtalk.com/robot/send?access_token=XXXXXX&timestamp=XXX&sign=XXX
        timestamp, sign_str = cal_timestamp_sign(secret)
        url = 'https://oapi.dingtalk.com/robot/send?access_token=' + robot_id + \
              '&timestamp=' + timestamp + '&sign=' + sign_str
        body = json.dumps(msg)
        r = requests.post(url, data=body, headers=headers, timeout=10)
        print(r.text)
        print('成功发送钉钉')
    except Exception as e:
        print("发送钉钉失败:", e)




# ==========辅助功能函数==========
# ===下次运行时间，和课程里面讲的函数是一样的
def next_run_time(time_interval, ahead_seconds=5):
    """
    根据time_interval，计算下次运行的时间，下一个整点时刻。
    目前只支持分钟和小时。
    :param time_interval: 运行的周期，15m，1h
    :param ahead_seconds: 预留的目标时间和当前时间的间隙
    :return: 下次运行的时间
    案例：
    15m  当前时间为：12:50:51  返回时间为：13:00:00
    15m  当前时间为：12:39:51  返回时间为：12:45:00
    10m  当前时间为：12:38:51  返回时间为：12:40:00
    5m  当前时间为：12:33:51  返回时间为：12:35:00
    5m  当前时间为：12:34:51  返回时间为：12:35:00

    1h  当前时间为：14:37:51  返回时间为：15:00:00
    2h  当前时间为：00:37:51  返回时间为：02:00:00

    30m  当前时间为：21日的23:33:51  返回时间为：22日的00:00:00
    5m  当前时间为：21日的23:57:51  返回时间为：22日的00:00:00

    ahead_seconds = 5
    15m  当前时间为：12:59:57  返回时间为：13:15:00，而不是 13:00:00
    """
    if time_interval.endswith('m') or time_interval.endswith('h'):
        pass
    elif time_interval.endswith('T'):
        time_interval = time_interval.replace('T', 'm')
    elif time_interval.endswith('H'):
        time_interval = time_interval.replace('H', 'h')
    else:
        print('time_interval格式不符合规范。程序exit')
        exit()

    ti = pd.to_timedelta(time_interval)
    now_time = datetime.datetime.now()
    # now_time = datetime(2019, 5, 9, 23, 50, 30)  # 指定now_time，可用于测试
    this_midnight = now_time.replace(hour=0, minute=0, second=0, microsecond=0)
    min_step = timedelta(minutes=1)

    target_time = now_time.replace(second=0, microsecond=0)

    while True:
        target_time = target_time + min_step
        delta = target_time - this_midnight
        if delta.seconds % ti.seconds == 0 and (target_time - now_time).seconds >= ahead_seconds:
            # 当符合运行周期，并且目标时间有足够大的余地，默认为60s
            break

    print('\n程序下次运行的时间：', target_time, '\n')
    return target_time


# ===依据时间间隔, 自动计算并休眠到指定时间
def sleep_until_run_time(time_interval, ahead_time=1, if_sleep=True):
    """
    根据next_run_time()函数计算出下次程序运行的时候，然后sleep至该时间
    :param time_interval:
    :param ahead_time:
    :param if_sleep:
    :return:
    """

    # 计算下次运行时间
    run_time = next_run_time(time_interval, ahead_time)

    # sleep
    if if_sleep:
        time.sleep(max(0, (run_time - datetime.datetime.now()).seconds))
        # 可以考察：print(run_time - n)、print((run_time - n).seconds)
        while True:  # 在靠近目标时间时
            if datetime.datetime.now() > run_time:
                break

    return run_time

# sleep时间配置
short_sleep_time = 1  # 用于和交易所交互时比较紧急的时间sleep，例如获取数据、下单
medium_sleep_time = 2  # 用于和交易所交互时不是很紧急的时间sleep，例如获取持仓
long_sleep_time = 10  # 用于较长的时间sleep