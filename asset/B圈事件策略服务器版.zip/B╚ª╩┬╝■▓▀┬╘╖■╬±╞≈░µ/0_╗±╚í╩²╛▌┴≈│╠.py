"""
# coding=utf8
"""
import pandas as pd
import ccxt
import time
import os
from DataConfig import *
from Function import *
pd.set_option('expand_frame_repr', False)  # 当列太多时不换行

today=datetime.date.today()
oneday=datetime.timedelta(days=1)
yesterday=today-oneday

begin_date = yesterday  # 手工设定开始时间
end_date = today  # 手工设定结束时间

date_list = []
date = pd.to_datetime(begin_date)
while date <= pd.to_datetime(end_date):
    date_list.append(str(date))
    date += datetime.timedelta(days=1)
start_time = '2021-01-01 00:00:00'
path = root_path + '/B事件策略实盘服务器/coin_database'
error_list = []
for start_time in date_list:
    # 遍历交易所
    for exchange in [ccxt.binance()]:
        # 获取交易所需要的数据
        market = exchange.load_markets()
        market = pd.DataFrame(market).T
        symbol_list = list(market['symbol'])
        mysymbol = mysymbol

        # 遍历交易对
        for symbol in mysymbol:
 # 遍历时间周期
            for time_interval in ['1h']:
                print(exchange.id, symbol, time_interval)
                try:
                    save_spot_candle_data_from_exchange(exchange, symbol, time_interval, start_time, path)
                except Exception as e:
                    print(e)
                    error_list.append('_'.join([exchange.id, symbol, time_interval]))
    print(error_list)