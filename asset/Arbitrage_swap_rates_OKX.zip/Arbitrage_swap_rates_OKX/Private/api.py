from Private.privateconfig import *
import okex.status_api as Status
import okex.Trade_api as Trade
import okex.Account_api as Account
import okex.Public_api as Public
import okex.Market_api as Market
import datetime

# 时间函数
def get_timestamp():
    now = datetime.datetime.now()
    t = now.isoformat("T", "milliseconds")
    return t + "Z"

# 调用各个接口
Status = Status.StatusAPI(api_key, secret_key, passphrase, False, flag)
tradeAPI = Trade.TradeAPI(api_key, secret_key, passphrase, False, flag)
accountAPI = Account.AccountAPI(api_key, secret_key, passphrase, False, flag)
publicAPI = Public.PublicAPI(api_key, secret_key, passphrase, False, flag)
marketAPI = Market.MarketAPI(api_key, secret_key, passphrase, False, flag)

# 公用参数调整
# okex网址
okurl = "www.okex.com"
# 滑点设置
slippage = 0.0014