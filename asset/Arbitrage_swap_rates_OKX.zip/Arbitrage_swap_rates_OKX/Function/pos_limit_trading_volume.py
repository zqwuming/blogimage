# -*- coding = utf-8 -*-
# @time:2021/12/8 23:28
# Author:ldx
# @File:pos_limit_trading_volume.py
# @Software:PyCharm

# -------------------------------
# main - 查询当前持仓标的交易限额 10%总持仓 30%24小时交易量
# -------------------------------

import pandas as pd
from time import sleep
from Private.api import marketAPI, publicAPI
from Common.common_no_print import get_position_no_print, get_pending_no_print
from Function.total_amount_20_OKEX import get_swap_median_price


def pos_limit_vol():
    # 持仓信息 获取当前交易对
    pos_name, pos_pos, pos_upl, pos_imr = get_position_no_print()
    pend_pos, pend_px, pend_id, pend_time = get_pending_no_print()

    pos_sum = {}

    # pos_pos + pend_pos
    for p_name in pos_name:
        # p_info = marketAPI.get_ticker(instId=p_name)
        if p_name[-4:] == "SWAP":
            swap_info = publicAPI.get_instruments(instType="SWAP", instId=p_name)
            ctVal = eval(swap_info['data'][0]['ctVal'])

            if p_name in list(pend_pos.keys()):
                pos_sum[p_name] = (ctVal * pend_pos[p_name]) + pos_pos[p_name]
            else:
                pos_sum[p_name] = pos_pos[p_name]
        else:
            pos_sum[p_name] = pos_pos[p_name]

    # 获取24小时交易量
    pos_vol24h = {}

    for p_name in pos_name:
        p_info = marketAPI.get_ticker(instId=p_name)

        if p_name[-4:] == "SWAP":
            swap_info = publicAPI.get_instruments(instType="SWAP", instId=p_name)
            ctVal = eval(swap_info['data'][0]['ctVal'])

            pos_vol24h[p_name] = ctVal * eval(p_info["data"][0]["vol24h"])
        else:
            pos_vol24h[p_name] = eval(p_info["data"][0]["vol24h"])

        sleep(0.5)

    # 获取标的永续总持仓量
    pos_oi = {}

    for p_swap_name in pos_name:
        sleep(0.5)
        if p_swap_name[-4:] == "SWAP":
            swap_info = publicAPI.get_instruments(instType="SWAP", instId=p_swap_name)
            ctVal = eval(swap_info['data'][0]['ctVal'])

            oi_info = publicAPI.get_open_interest(instType="SWAP", instId=p_swap_name)
            pos_oi[p_swap_name] = ctVal * eval(oi_info["data"][0]["oi"])

    # 进入分析阶段
    d_ID = []
    d_POS = []
    d_SWAP24 = []
    d_MARGIN24 = []
    d_SWAP_oi = []
    d_PRICE = []

    for p_name in list(pos_sum.keys()):
        if p_name[-4:] == "SWAP":
            d_ID.append(p_name)
            d_POS.append(pos_sum[p_name])

    for p_name in d_ID:
        d_SWAP24.append(pos_vol24h[p_name])
        d_SWAP_oi.append(pos_oi[p_name])
        d_MARGIN24.append(pos_vol24h[p_name[:-5]])
        d_price = get_swap_median_price(p_name)
        d_PRICE.append(d_price)

    data = {
        "ID": d_ID,
        "POS": d_POS,
        "SWAP24": d_SWAP24,
        "MARGIN24": d_MARGIN24,
        "SWAPoi": d_SWAP_oi,
        "PRICE": d_PRICE
    }

    df = pd.DataFrame(data)

    print(df)

    a = list(0.3 * df["SWAP24"])
    b = list(0.3 * df["MARGIN24"])
    c = list(0.1 * df["SWAPoi"])

    # 比较 30%24交易量 和 10%持仓量
    abc_list = zip(a, b, c)

    MIN_list = []

    for abc in abc_list:
        MIN_list.append(min(abc))

    df["MIN"] = MIN_list

    df["PER"] = 100 * df["POS"] / df["MIN"]

    result = df[['ID', 'POS', 'MIN', "PER"]]
    pd.set_option('display.float_format', lambda x: '%.3f' % x)

    print(result)
