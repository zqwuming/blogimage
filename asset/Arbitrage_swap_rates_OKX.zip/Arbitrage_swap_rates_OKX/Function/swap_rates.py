# -*- coding = utf-8 -*-
# @time:2021/12/3 15:22
# Author:ldx
# @File:swap_rates.py
# @Software:PyCharm

# -------------------------------
# main - 资金费套利
# 参数 type:positive negative 正负资金费方向
# -------------------------------


from time import sleep
from uuid import uuid4
from Private.api import marketAPI
from Common.common import set_leverage, inquire_info
from Common.common import account_about,get_position,get_pending,prepare_var
from Common.public_doc_link_info import get_rates_history
from Common.Transaction_settings import get_ms_info, calculation, fee_info, rate_info, calculation_dev
from Function.swap_rates_common import rates_set_settings, pos_max_buy, calculate_profit
from Function.swap_rates_common import calculate_open_list, open_order_buy, calculate_close_list, close_order_sell


# 开仓函数 Open a position
def open_swap_rates(type):
    # 现实账户信息
    eq, availEq = account_about()
    # 持仓信息 获取当前交易对
    pos_name, pos_pos, pos_upl, pos_imr = get_position()
    pend_pos, pend_px, pend_id, pend_time = get_pending()
    # 获得需要进行套利的标的名称
    spot_name, margin_name, swap_name, p_name = prepare_var()
    ctVal, m_tickSz, s_tickSz, m_lotSz, s_lotSz, m_minSz, s_minSz = get_ms_info(margin_name)
    # 获取中间值 最近成交价 最大金额
    median, swap_last, max_money = calculation(margin_name, swap_name, ctVal)
    p_log_p, p_0, p_1, p_2, p_3, p_4, p_5, p_bzj = rates_set_settings(type, margin_name, swap_name, ctVal, pos_pos, pos_imr, pend_pos, pend_px)
    set_leverage(margin_name, swap_name, p_2, p_4)  # 一键设置杠杆
    m_fee, s_fee = fee_info(margin_name)  # 获取手续费
    print(m_fee, s_fee)

    u_rate = get_rates_history(m_name='USDT') # 获取借U利率
    # b_rate = get_rates_history(name=margin_name[:-5])  # 获取借B利率
    rate = eval(rate_info(swap_name))  # 获取资金费率

    m_max_buy, m_max_sell, s_max_buy = pos_max_buy(margin_name, swap_name) # 持仓最大可交易量

    # p2为杠杆 p3为杠杆最低保证金
    p_swap, p_margin, n, p_margin_list, p_swap_list = calculate_open_list(swap_name, p_2, p_3, ctVal, max_money, p_bzj, m_max_buy)

    # 计算利润
    calculate_profit(s_fee, m_fee, rate, u_rate)

    yes = input("\nPlease enter any key to start the program!\n")

    m = 1
    while n > 0:
        p_margin = p_margin_list[m - 1]
        p_swap = p_swap_list[m - 1]
        # 生成订单号
        client_oid = 'zjf' + str(uuid4())[:8]

        while True:
            m_max_buy, m_max_sell, s_max_buy = pos_max_buy(margin_name, swap_name)

            if type == 'positive':
                m_max_open_number = m_max_buy
            else:
                m_max_open_number = m_max_sell

            string = "当前杠杆开仓量为{:.3f} 最大开仓量为{:.3f} ".format(p_margin, m_max_open_number)

            if p_margin <= m_max_open_number:
                pass
            else:
                print(string, "不可开仓")
                break

            # 获取偏离度
            dev = calculation_dev(swap_name, median, string)

            if abs(dev) < 0.08: # 如果偏离度绝对值小于0.8% 开始下单
                lever_order, swap_order = open_order_buy(type,margin_name,swap_name,p_swap,client_oid,m_fee,ctVal,m_tickSz)
                break

            sleep(5)

        # 查询下单情况 自动配价格
        j = 1
        while True:

            s, l, s_price, l_price = inquire_info(client_oid, margin_name, swap_name, ctVal)

            if s == 'filled' and l == 'filled':
                print("\n=============第{}笔{}完成交易！剩余{}笔。=============".format(m, client_oid, n - 1))
                break
            else:
                print("{}/{} 继续等待。。。   已运行{}s\n".format(m, m + n - 1, j * 5))

            j = j + 1
            sleep(5)

        n = n - 1
        m = m + 1
        sleep(1)


# 平仓函数 Close a position
def close_swap_rates(type):
    # 持仓信息 获取当前交易对
    pos_name, pos_pos, pos_upl, pos_imr = get_position()
    # 获得需要进行套利的标的名称
    print("\n本程序即将进行现货-永续合约的资金费套利 平仓。")
    # 获得需要进行套利的标的名称
    spot_name, margin_name, swap_name, p_name = prepare_var()

    # 刷新获取价格
    swap_info = marketAPI.get_ticker(swap_name)
    last = eval(swap_info['data'][0]['last'])

    ctVal, m_tickSz, s_tickSz, m_lotSz, s_lotSz, m_minSz, s_minSz = get_ms_info(margin_name)

    # 获取中间值 最近成交价 最大金额
    median, swap_last, max_money = calculation(margin_name, swap_name, ctVal)

    print("\n当前持仓 {} USDT\n{} : {}\n{} : {}\n".format(abs(pos_pos[margin_name] * last - eval(pos_upl[margin_name])),
                                                      margin_name, pos_pos[margin_name], swap_name, pos_pos[swap_name]))

    a = pos_pos[margin_name]
    b = pos_pos[swap_name]

    p_swap, p_margin, n, p_margin_list, p_swap_list = calculate_close_list(swap_name,a,b,ctVal,max_money)

    yes = input("\nPlease enter any key to start the program!")

    m = 1
    while n > 0:
        p_lever = p_margin_list[m - 1]
        p_swap = p_swap_list[m - 1]

        client_oid = 'zjf' + str(uuid4())[:8]

        # 如果偏离度绝对值小于0.8% 开始下单
        while True:
            string = ''
            # 获取偏离度
            dev = calculation_dev(swap_name, median, string)

            if abs(dev) < 0.08:
                margin_order, swap_order = close_order_sell(type, margin_name, swap_name, p_margin, p_swap, client_oid, s_tickSz)
                break
            sleep(5)

        # 查询下单情况 自动配价格
        j = 1
        while True:

            s, l, s_price, l_price = inquire_info(client_oid, margin_name, swap_name, ctVal)

            if s == 'filled' and l == 'filled':
                print("\n=============第{}笔{}完成交易！剩余{}笔。=============".format(m, client_oid, n - 1))
                break

            else:
                print("继续等待。。。   已运行{}s\n".format(j * 5))
            j = j + 1
            sleep(5)

        m = m + 1
        n = n - 1
