# -*- coding = utf-8 -*-
# @time:2021/12/8 23:15
# Author:ldx
# @File:total_amount_20_OKEX.py
# @Software:PyCharm

# -------------------------------
# main - OKEX 前20个可套利的资金总量
# -------------------------------

import numpy as np
import pandas as pd
import time as t
from Private.api import *

# 获取资金费信息
def zjf_info():
    swap_list = []
    # 获取交易产品基础信息
    all_info = publicAPI.get_instruments(instType='SWAP')
    all_info = all_info['data']
    for info in all_info:
        if info['settleCcy'] == 'USDT':
            swap_list.append(info['instId'])

    # 获取永续合约当前资金费率

    his_swap_dic = {}
    his_swap_list1 = []
    his_swap_list2 = []
    his_swap_list3 = []
    his_swap_list4 = []

    hrate = publicAPI.funding_rate_history(instId="BTC-USDT-SWAP")

    # 初始时间戳
    t0 = hrate['data'][0]['fundingTime']
    t1 = int(t0) - 2851300000
    t2 = int(t0) - 2 * 2851300000
    t3 = int(t0) - 3 * 2851300000

    for n in swap_list:
        his_swap_list1.append(n)
        hrate = publicAPI.funding_rate_history(instId=n)
        hrate2 = publicAPI.funding_rate_history(instId=n,before=str(t2))
        hrate3 = publicAPI.funding_rate_history(instId=n,before=str(t3))

        h = len(hrate['data'])
        h90 = len(hrate2['data']) + len(hrate3['data'])

        hsum = 0
        for i in range(10,h):
            hsum = hsum + float(hrate['data'][i]['realizedRate'])

        his_swap_list3.append(hsum)  # 30天所有资金费累加
        havg = hsum / 30 * 3
        his_swap_list2.append(havg)  # 每天平均资金费

        hsum90 = 0
        if h90 < 200:
            hsum90 = 0
        else:
            for i in range(h):
                hsum90 = hsum90 + float(hrate['data'][i]['realizedRate'])

            for j in range(len(hrate2['data']) ):
                hsum90 = hsum90 + float(hrate['data'][j]['realizedRate'])

            for k in range(30,len(hrate3['data'])):
                hsum90 = hsum90 + float(hrate['data'][k]['realizedRate'])

        his_swap_list4.append(hsum90)  # 90天所有资金费累加

    his_swap_dic['ID'] = his_swap_list1
    his_swap_dic['DAY'] = his_swap_list2
    his_swap_dic['SUM30'] = his_swap_list3
    his_swap_dic['SUM90'] = his_swap_list4

    data = pd.DataFrame(his_swap_dic)

    # 取绝对值
    data['abshsum'] = abs(data['SUM30'])

    data = data[data['SUM30'] > 0]
    df = data.sort_values(by='abshsum', ascending=False)
    df = df[['ID', 'SUM30', 'SUM90']].head(20)

    return df


# 获取24小时的交易数量 单位：币
def get_vol24h(p_name):
    t.sleep(0.5)
    # 获取24小时交易量
    p_info = marketAPI.get_ticker(instId=p_name)
    if p_name[-4:] == "SWAP":
        swap_info = publicAPI.get_instruments(instType="SWAP", instId=p_name)
        ctVal = eval(swap_info['data'][0]['ctVal'])

        p_vol24h = ctVal * eval(p_info["data"][0]["vol24h"])
    else:
        p_vol24h = eval(p_info["data"][0]["vol24h"])

    return p_vol24h


# 获取当前交易所总持仓信息（永续合约）
def get_oi(p_swap_name):
    t.sleep(0.5)
    swap_info = publicAPI.get_instruments(instType="SWAP", instId=p_swap_name)
    ctVal = eval(swap_info['data'][0]['ctVal'])
    oi_info = publicAPI.get_open_interest(instType="SWAP", instId=p_swap_name)
    p_oi = ctVal * eval(oi_info["data"][0]["oi"])

    return p_oi


# 获取前24个小时每3分钟的 median
def get_swap_median_price(swap_name):
    swap_index = marketAPI.get_candlesticks(swap_name, bar='3m')
    swap_index = swap_index['data']
    v_price = []
    for v in swap_index[:480]:
        v_price.append(eval(v[4]))
    swap_median_price = np.median(v_price)
    return swap_median_price


def total_amount_20_okex():
    # 获取交易产品基础信息 永续合约 和 币币杠杆
    instId_SWAP = publicAPI.get_instruments(instType="SWAP")
    instId_SWAP_list = instId_SWAP["data"]

    SWAP_NAME_list = []  # live的永续合约

    for sl in instId_SWAP_list:
        if sl["instType"] == "SWAP" and sl["settleCcy"] == "USDT" and sl["state"] == "live":
            SWAP_NAME_list.append(sl["instId"])

    instId_MARGIN = publicAPI.get_instruments(instType="MARGIN")
    instId_MARGIN_list = instId_MARGIN["data"]

    MARGIN_NAME_list = []  # live的币币杠杆

    for ml in instId_MARGIN_list:
        if ml["instType"] == "MARGIN" and ml["state"] == "live":
            MARGIN_NAME_list.append(ml["instId"])

    # SWAP_NAME_list 和 MARGIN_NAME_list 是live状态的list

    Arbitrage_NAME_list = []

    for sl in SWAP_NAME_list:
        if sl[:-5] in MARGIN_NAME_list:
            Arbitrage_NAME_list.append(sl)

    # print(Arbitrage_NAME_list)
    #
    # for p_name in Arbitrage_NAME_list:
    #     rate_info = publicAPI.get_funding_rate(instId=p_name)

    df = zjf_info()

    # 获取永续合约24小时数据

    # 获取币币杠杆24小时数据

    # 获取总持仓量 数据

    d_SWAP24 = []
    d_MARGIN24 = []
    d_SWAP_oi = []
    d_PRICE = []

    for d_name in list(df["ID"]):
        if d_name in Arbitrage_NAME_list:
            swap24 = get_vol24h(d_name)
            margin24 = get_vol24h(d_name[:-5])
            swap_oi = get_oi(d_name)
        else:
            swap24 = get_vol24h(d_name)
            margin24 = 0
            swap_oi = get_oi(d_name)

        d_SWAP24.append(swap24)
        d_MARGIN24.append(margin24)
        d_SWAP_oi.append(swap_oi)

        d_price = get_swap_median_price(d_name)

        d_PRICE.append(d_price)

    df["swap24"] = d_SWAP24
    df["margin24"] = d_MARGIN24
    df["swap_oi"] = d_SWAP_oi
    df["PRICE"] = d_PRICE

    a = list(0.3 * df["swap24"])
    b = list(0.3 * df["margin24"])
    c = list(0.1 * df["swap_oi"])

    # 比较 30%24交易量 和 10%持仓量
    abc_list = zip(a, b, c)

    MIN_list = []

    for abc in abc_list:
        MIN_list.append(min(abc))

    df["MIN"] = MIN_list

    df["Arbitrage"] = df["MIN"] * df["PRICE"]

    # 计算标的24小时平均价格

    result = df[['ID', 'SUM30', 'SUM90', 'MIN', "Arbitrage"]]
    pd.set_option('display.float_format', lambda x: '%.3f' % x)
    print(result)

    print("前20可套利的金额为 {:.2f} USDT".format(df["Arbitrage"].sum()))