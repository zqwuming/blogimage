# -*- coding = utf-8 -*-
# @time:2021/12/3 15:34
# Author:ldx
# @File:swap_rates_common.py
# @Software:PyCharm

# -------------------------------
# common - 资金费套利
# -------------------------------

import pandas as pd
from Private.api import accountAPI, marketAPI, tradeAPI
from Common.common import order_state
from Common.Transaction_settings import make_px
from Common.Transaction_ways import pressing_transaction_open, pressing_transaction_close
from Common.public_doc_link_info import get_lever_cross_info, get_swap_cross_info
from Common.public_doc_link_info import v5_public_lever, v5_public_swap, get_interest_rate

# 持仓的最大开仓量
def pos_max_buy(margin_name, swap_name):
    # 杠杆的最大交易量
    maxsize_m = accountAPI.get_maximum_trade_size(instId=margin_name, tdMode='cross', ccy='USDT')
    # 永续的最大交易量
    maxsize_s = accountAPI.get_maximum_trade_size(instId=swap_name, tdMode='cross')

    m_max_buy = eval(maxsize_m['data'][0]['maxBuy'])
    m_max_sell = eval(maxsize_m['data'][0]['maxSell'])
    s_max_buy = eval(maxsize_s['data'][0]['maxBuy'])


    return m_max_buy, m_max_sell, s_max_buy


# 开仓输入函数 计算开仓的交易列表
def calculate_open_list(swap_name, p_2, p_3, ctVal, max_money, p_bzj, m_max_buy):
    # -------------------------------
    # p_swap float 永续合约交易数量
    # p_margin float 币币杠杆交易数量
    # n             int 交易次数
    # p_margin_list list 币币杠杠杆待交易列表
    # p_swap_list list 永续合约待交易列表
    # -------------------------------
    # 刷新获取价格
    swap_info = marketAPI.get_ticker(swap_name)
    last = eval(swap_info['data'][0]['last'])

    open_list_sum_money = float(p_2) * float(p_3)

    # m_max_buy 为杠杆账户最多可交易的数量
    if m_max_buy * last < open_list_sum_money:
        open_list_sum_money  = 0.95 * m_max_buy * last

    print("\n本次保证金为:", p_bzj,
          "本次套利总金额为:", open_list_sum_money,
          "资金使用率为:{:.2f}%:".format(100 * float(open_list_sum_money) / float(p_bzj)))


    account_info = accountAPI.get_account('USDT')
    a_usdt = account_info['data'][0]['details'][0]
    usdtEq = 0.25 * eval(a_usdt['eq'])

    print("25%账户USDT权益为:{:.2f}".format(usdtEq))
    print("33%每小时交易金额为:{:.2f}".format(max_money))
    print("杠杆账户最大开仓量为:", m_max_buy)

    p_swap = (open_list_sum_money / last) // ctVal
    p_margin = p_swap * ctVal

    print("\n杠杆总个数为:{} 永续总张数为:{}".format(p_margin,p_swap))

    p_swap_list = []
    p_margin_list = []

    n = 1

    # 设计自动识别下单次数
    if usdtEq < max_money:
        max_money = int(usdtEq)

    if open_list_sum_money < max_money:
        p_swap_list.append(p_swap)
        p_margin_list.append(p_margin)

    else:
        n = int(open_list_sum_money//max_money) + 1

        for l in range(n):
            l_swap = p_swap//n

            if l == range(n)[-1]:
                l_swap = p_swap - (n-1) * p_swap_list[0]

            p_swap_list.append(l_swap)
            p_margin_list.append(l_swap * ctVal)

    print("\n实际参数:\n交易的总金额为:{} USDT 资金使用率为:{:.2f}% 交易:{}次".format(p_margin * last,100 * (p_margin * last)/float(p_bzj), n))
    print("永续交易序列:", p_swap_list, "\n杠杆交易序列:", p_margin_list)

    return p_swap, p_margin, n, p_margin_list, p_swap_list


# 平仓输入 计算平仓的交易列表
def calculate_close_list(swap_name,a,b,ctVal,max_money):
    # 刷新获取价格
    swap_info = marketAPI.get_ticker(swap_name)
    last = eval(swap_info['data'][0]['last'])

    if a<0:
        a = a*(-1)

    print("100%平仓")
    p_margin = a
    p_swap = int(b / ctVal)

    print("\n本次交易杠杆数量:{}\n本次交易合约数量:{}".format(p_margin, p_swap))

    account_info = accountAPI.get_account('USDT')
    a_usdt = account_info['data'][0]['details'][0]
    usdtEq = 0.25 * eval(a_usdt['eq'])

    print("25%账户USDT权益为:{:.2f}".format(usdtEq))
    print("33%每小时交易金额为:{:.2f}".format(max_money))

    close_list_sum_money = p_margin * last


    p_margin_list = []
    p_swap_list = []

    n = 1

    # 设计自动识别下单次数
    if usdtEq < max_money:
        max_money = int(usdtEq)

    if close_list_sum_money < max_money:
        p_swap_list.append(p_swap)
        p_margin_list.append(p_margin)

    else:
        n = int(close_list_sum_money // max_money) + 1

        for l in range(n):

            l_swap = p_swap // n

            if l == range(n)[-1]:
                print('最后一次交易抹平。')
                l_swap = p_swap - (n - 1) * p_swap_list[0]

                p_swap_list.append(l_swap)
                p_margin_list.append(a - ((n - 1) * p_swap_list[0] * ctVal))
                break

            p_swap_list.append(l_swap)
            p_margin_list.append(l_swap * ctVal)

    print("\n交易的总金额为:{} USDT 交易:{}次".format(close_list_sum_money, n))
    print("永续交易序列", p_swap_list, "\n杠杆交易序列:", p_margin_list)


    return p_swap, p_margin, n, p_margin_list, p_swap_list


# 计算利润的函数
def calculate_profit(s_fee, m_fee, rate, u_rate):
    # 计算利润
    fee = 100 * (2 * s_fee + 2 * m_fee)
    interest = abs(100 * rate) + fee - 0.33 * eval(u_rate[:-1])

    dpy = 3 * abs(100 * rate) + fee - eval(u_rate[:-1])
    apy = 365 * dpy

    print("\n本次资金费率为{:.3f}%".format(abs(100 * rate)),
          "\n本次全部手续费为{:.3f}%".format(fee),
          "\n借USDT日利息为{}".format(u_rate),
          "\n单次真实收益率为{:.3f}%".format(interest))

    print("\nDPY:{:.3f}% APY:{:.3f}%".format(dpy, apy))


# 资金费 匹配函数
def rates_match(parameters):
    type, margin_name, swap_name, txt_margin, txt_swap, p_min, p_max, p_interval, last, ctVal, pos_pos, pos_imr, availEq, p_max_bi, pend_pos, pend_px = parameters
    p_log = pd.DataFrame(
        columns=('序列', '套利', '需要保证金', '资金使用率%', '杠杆', '杠杆最低保证金率', '杠杆最低保证金', '永续', '永续最低保证金率', '永续最低保证金'))
    index = 0
    for p in range(p_min, p_max, p_interval):
        # 根据杠杆的范围来划定档位
        lever_max, lever_pre = get_lever_cross_info(p, txt_margin, type, last)
        swap_n = (p / last) // ctVal
        swap_max, swap_pre = get_swap_cross_info(swap_n, txt_swap)

        if eval(lever_pre) == 1:
            break

        # -------------------------------
        # d0 序列
        # d1 套利
        # d2 需要保证金
        # d3 资金使用率%
        # d4 杠杆
        # d5 杠杆最低保证金率
        # d6 杠杆最低保证金
        # d7 永续
        # d8 永续最低保证金率
        # d9 永续最低保证金
        # -------------------------------

        d0 = index
        d1 = p
        d2 = p * (eval(swap_pre) + eval(lever_pre))
        d3 = 100 * p / (p * (eval(swap_pre) + eval(lever_pre)))
        d4 = lever_max
        d5 = 100 * eval(lever_pre)
        d6 = p * eval(lever_pre)
        d7 = swap_max
        d8 = 100 * eval(swap_pre)
        d9 = p * eval(swap_pre)

        p_log.loc[index] = [d0, d1, d2, d3, d4, d5, d6, d7, d8, d9]

        pre = 100 * p / (p * (eval(swap_pre) + eval(lever_pre)))

        if pre < 95:
            break

        # 杠杆最低保证金 最大值为限
        if type == "negative":
            if p * eval(lever_pre) * float(lever_max) >= p_max_bi:
                break

        index = index + 1

    pos_imr_s = 0
    pos_imr_m = 0

    # 检查pos仓位持仓数量 检查档位 进行杠杆设置
    if swap_name in list(pos_pos.keys()):
        if margin_name in list(pos_pos.keys()):
            pos_imr_s = eval(pos_imr[swap_name])
            pos_imr_m = eval(pos_imr[margin_name])
        else:
            pos_imr_s = eval(pos_imr[swap_name])
            # 检查pend挂单的数量 添加到保证金里面
            if margin_name in list(pend_pos.keys()):
                # 获取币币杠杆倍数
                margin_lever = accountAPI.get_leverage(instId=margin_name, mgnMode='cross')
                margin_lever = eval(margin_lever["data"][0]["lever"])
                pos_imr_m = pend_pos[margin_name] * pend_px[margin_name] / margin_lever

    print("已占用保证金\n杠杆{:.2f}\n永续{:.2f}\n合计{:.2f}".format(pos_imr_m, pos_imr_s, pos_imr_m + pos_imr_s))

    # pos_imr_s float 永续合约保证金
    # pos_imr_m float 币币杠杆保证金

    availEq = pos_imr_s + pos_imr_m + availEq

    p_log_m = p_log.to_dict()['套利']
    p_log_d = p_log.to_dict()['需要保证金']
    p_log_lever = p_log.to_dict()['杠杆']
    p_log_lever_u = p_log.to_dict()['杠杆最低保证金']
    p_log_swap = p_log.to_dict()['永续']
    p_log_swap_u = p_log.to_dict()['永续最低保证金']

    p_log_p = 0
    p_bzj = 0

    if availEq > p_log_d[list(p_log_d.keys())[-1]]:
        availEq = p_log_d[list(p_log_d.keys())[-1]]

    if p_interval == 100:
        for log in list(p_log_d.keys()):
            if availEq <= p_log_d[log]:
                if log == 0:
                    p_log_p = 0
                else:
                    p_log_p = log - 1
                    p_bzj = p_log_d[p_log_p]
                print('\n需要保证金', p_bzj, '\n杠杆', p_log_lever[p_log_p], '杠杆最低保证金', p_log_lever_u[p_log_p],
                      '\n永续', p_log_swap[p_log_p], '永续最低保证金', p_log_swap_u[p_log_p])
                break

    else:
        for log in list(p_log_d.keys()):
            if availEq <= p_log_d[log]:
                p_log_p = log
                print("区间范围为", p_log_p, '套利金额', p_log_m[p_log_p], '保证金', p_log_d[p_log_p])
                break

    # -------------------------------
    # p_log_p   区间范围
    # p_0       套利金额
    # p_1       保证金
    # p_2       杠杆
    # p_3       杠杆最低保证金
    # p_4       永续
    # p_5       永续最低保证金
    # p_bzj     保证金
    # -------------------------------

    p_0 = p_log_m[p_log_p]
    p_1 = p_log_d[p_log_p]
    p_2 = p_log_lever[p_log_p]
    p_3 = p_log_lever_u[p_log_p]
    p_4 = p_log_swap[p_log_p]
    p_5 = p_log_swap_u[p_log_p]

    if swap_name in list(pos_pos.keys()):
        p_bzj = p_1 - pos_imr_s - pos_imr_m
        print('\n(计算后)本次增加的保证金',p_bzj,
              '\n杠杆', p_2, '杠杆最低保证金', p_3 - pos_imr_m,
              '\n永续', p_4, '永续最低保证金', p_5 - pos_imr_s)

        p_1 = p_bzj
        p_3 = p_3 - pos_imr_m
        p_5 = p_5 - pos_imr_s

    return p_log_p, p_0, p_1, p_2, p_3, p_4, p_5, p_bzj


# 匹配流程
def rates_set_settings_match(parameters):
    type, margin_name, swap_name, txt_margin, txt_swap, last, ctVal, pos_pos, pos_imr, availEq, p_max_usdt, p_max_bi, pend_pos, pend_px = parameters
    print("\n------匹配开始------")

    if type == "positive":
        p_max = p_max_usdt
    else:
        p_max = p_max_bi

    parameters_0 = (type, margin_name, swap_name, txt_margin, txt_swap, 100, p_max, 10000, last, ctVal, pos_pos, pos_imr, availEq, p_max_bi, pend_pos, pend_px)
    p_log_p, p_0, p_1, p_2, p_3, p_4, p_5, p_bzj = rates_match(parameters_0)

    if p_log_p == 0:
        parameters_1 = (type, margin_name, swap_name, txt_margin, txt_swap, 100, 5000, 100, last, ctVal, pos_pos, pos_imr, availEq, p_max_bi, pend_pos, pend_px)
        p_log_p, p_0, p_1, p_2, p_3, p_4, p_5, p_bzj = rates_match(parameters_1)

    else:
        parameters_2 = (type, margin_name, swap_name, txt_margin, txt_swap, p_0 - 10000, p_0, 1000, last, ctVal, pos_pos, pos_imr, availEq, p_max_bi, pend_pos, pend_px)
        p_log_p, p_0, p_1, p_2, p_3, p_4, p_5, p_bzj = rates_match(parameters_2)

        parameters_3 = (type, margin_name, swap_name, txt_margin, txt_swap, p_0 - 1000, p_0, 100, last, ctVal, pos_pos, pos_imr, availEq, p_max_bi, pend_pos, pend_px)
        p_log_p, p_0, p_1, p_2, p_3, p_4, p_5, p_bzj = rates_match(parameters_3)

    return p_log_p, p_0, p_1, p_2, p_3, p_4, p_5, p_bzj


# 资金费初始化设置
def rates_set_settings(type, margin_name, swap_name, ctVal, pos_pos, pos_imr, pend_pos, pend_px):

    txt_margin = v5_public_lever(margin_name)
    txt_swap = v5_public_swap(margin_name)

    # 刷新获取价格
    swap_info = marketAPI.get_ticker(swap_name)
    last = eval(swap_info['data'][0]['last'])

    account_info = accountAPI.get_account('USDT')
    a_usdt = account_info['data'][0]['details'][0]

    availEq = eval(a_usdt['availEq'])

    if type == "positive":
        p_max_usdt = int(eval(txt_margin["data"][-1]["quoteMaxBorrow"]))  # 标的杠杆最大借U量
        p_max = float(get_interest_rate(m_name='USDT'))  # 当前账号等级最多可借U
        print("\n当前账户可用保证金为:{:.3f} USDT".format(availEq))
        print("\n当前标的最高可借金额为:{:.3f} USDT".format(p_max_usdt))
        print("\n当前账户最高可借金额为:{:.3f} USDT".format(p_max))

        if p_max < p_max_usdt:
            p_max_usdt = p_max

        # 留出部分空间浮动 使用95%可用保证金
        availEq = 0.95 * availEq

        p_max_bi = 0

        parameters = (type, margin_name, swap_name, txt_margin, txt_swap, last, ctVal, pos_pos, pos_imr, availEq, p_max_usdt, p_max_bi, pend_pos, pend_px)
        p_log_p, p_0, p_1, p_2, p_3, p_4, p_5, p_bzj = rates_set_settings_match(parameters)

    else:
        p_max_bi = int(eval(txt_margin["data"][-1]["maxAmount"]))  # 该标的最多借B多少
        p_name = margin_name[:-5]
        p_max = float(get_interest_rate(m_name=p_name))  # 该账户最多借B多少
        print("\n当前账户可用保证金为:{:.3f} USDT".format(availEq))
        print("\n当前标的最高可借币数量为:{} {}".format(p_max_bi, p_name))
        print("\n当前账户最高可借币数量为:{} {}".format(p_max, p_name))

        if p_max < p_max_bi:
            p_max_bi = p_max

        p_max_bi = int(last * p_max_bi)

        availEq = 0.95 * availEq

        p_max_usdt = 0

        parameters = (type, margin_name, swap_name, txt_margin, txt_swap, last, ctVal, pos_pos, pos_imr, availEq, p_max_usdt, p_max_bi, pend_pos, pend_px)
        p_log_p, p_0, p_1, p_2, p_3, p_4, p_5, p_bzj = rates_set_settings_match(parameters)

    return p_log_p, p_0, p_1, p_2, p_3, p_4, p_5, p_bzj


# 资金费订单开仓 下单函数
def open_order_buy(type, margin_name, swap_name, p_swap, client_oid, m_fee, ctVal, m_tickSz = None):
    print('◆' * 6 + '开始下单程序' + '◆' * 6)
    # 下单刷新
    swap_info = marketAPI.get_ticker(swap_name)

    if type == 'positive':
        price = swap_info['data'][0]['askPx']
        # 计算下单的数量
        d = str(int(p_swap))
        c = str(int(p_swap) * ctVal / (1 + m_fee))

        # 合约 优先下单
        swap_order = tradeAPI.place_order(instId=swap_name, tdMode='cross', clOrdId=client_oid + 's', side='sell',
                                          posSide='short', ordType='post_only', sz=d, px=price)

    else:
        price = swap_info['data'][0]['bidPx']
        # 计算下单的数量
        d = str(int(p_swap))
        c = str(int(p_swap) * ctVal)

        # 合约 优先下单
        swap_order = tradeAPI.place_order(instId=swap_name, tdMode='cross', clOrdId=client_oid + 's', side='buy',
                                          posSide='long', ordType='post_only', sz=d, px=price)

    print('◆' * 6 + '合约优先下单' + '◆' * 6)

    s_avgPx = pressing_transaction_open(type, swap_name, client_oid, ctVal)

    p_avgPx = make_px(s_avgPx, m_tickSz)

    if type == 'positive':
        # 杠杆交易下单
        margin_order = tradeAPI.place_order(instId=margin_name, tdMode='cross', ccy='USDT', clOrdId=client_oid + 'm',
                                           side='buy', ordType='post_only', sz=c, px=p_avgPx, reduceOnly='false')
    else:
        # 杠杆交易下单
        margin_order = tradeAPI.place_order(instId=margin_name, tdMode='cross', ccy='USDT', clOrdId=client_oid + 'm',
                                           side='sell', ordType='post_only', sz=c, px=p_avgPx, reduceOnly='false')

    l_order = tradeAPI.get_orders(margin_name, clOrdId=client_oid + 'm')

    l_order = l_order['data'][0]
    l_state = order_state(l_order['state'])

    print("现货 {} {}|{} {}|{}".format(l_state, l_order['avgPx'], l_order['px'], l_order['accFillSz'], l_order['sz']))

    print('◆' * 6 + '完成下单程序' + '◆' * 6)

    return margin_order, swap_order


# 资金费订单平仓 下单函数
def close_order_sell(type, margin_name, swap_name, p_margin, p_swap, client_oid, s_tickSz):
    print('◆' * 6 + '开始下单程序' + '◆' * 6)
    # 下单刷新
    swap_info = marketAPI.get_ticker(swap_name)

    # 获取下单价格 成交价
    if type == 'positive':
        price = swap_info['data'][0]['askPx']
        c = str(p_margin)
        d = str(int(p_swap))

        # 杠杆交易下单
        margin_order = tradeAPI.place_order(instId=margin_name, tdMode='cross', ccy='USDT', clOrdId=client_oid + 'm',
                                            side='sell', ordType='post_only', sz=c, px=price, reduceOnly='false')

    else:
        price = swap_info['data'][0]['bidPx']
        c = str(p_margin)
        d = str(int(p_swap))

        # 杠杆交易下单
        margin_order = tradeAPI.place_order(instId=margin_name, tdMode='cross', ccy='USDT', clOrdId=client_oid + 'm',
                                            side='buy', ordType='post_only', sz=c, px=price, reduceOnly='false')

    print('◆' * 6 + '杠杆优先下单' + '◆' * 6)

    m_avgPx = pressing_transaction_close(type, margin_name, client_oid)

    p_avgPx = make_px(m_avgPx, s_tickSz)

    if type == 'positive':
        # 合约交易下单 下单数量，买入或卖出合约的数量（以张计数）
        swap_order = tradeAPI.place_order(instId=swap_name, tdMode='cross', clOrdId=client_oid + 's', side='buy',
                                          posSide='short', ordType='post_only', sz=d, px=p_avgPx)
    else:
        # 合约交易下单
        swap_order = tradeAPI.place_order(instId=swap_name, tdMode='cross', clOrdId=client_oid + 's', side='sell',
                                          posSide='long', ordType='post_only', sz=d, px=p_avgPx)

    print('◆' * 6 + '完成下单程序' + '◆' * 6)

    return margin_order, swap_order
