# -*- coding = utf-8 -*-
# @time:2021/12/8 20:36
# Author:ldx
# @File:pos_leverage_reset_common.py
# @Software:PyCharm

# -------------------------------
# common - 杠杆重置 实现最优杠杆
# -------------------------------


import pandas as pd
from Private.api import accountAPI
from Common.public_doc_link_info import get_lever_cross_info, get_swap_cross_info


# 匹配流程
def rates_set_settings_match_reset(parameters):
    type, margin_name, swap_name, txt_margin, txt_swap, last, ctVal, pos_pos, pos_imr, availEq, p_max_usdt, p_max_bi, pend_pos, pend_px = parameters

    if type == "positive":
        p_max = p_max_usdt
    else:
        p_max = p_max_bi

    parameters_0 = (type, margin_name, swap_name, txt_margin, txt_swap, 100, p_max, 10000, last, ctVal, pos_pos, pos_imr, availEq, p_max_bi, pend_pos, pend_px)
    p_log_p, p_0, p_1, p_2, p_3, p_4, p_5, p_bzj = rates_match_reset(parameters_0)

    if p_log_p == 0:
        parameters_1 = (type, margin_name, swap_name, txt_margin, txt_swap, 100, 5000, 100, last, ctVal, pos_pos, pos_imr, availEq, p_max_bi, pend_pos, pend_px)
        p_log_p, p_0, p_1, p_2, p_3, p_4, p_5, p_bzj = rates_match_reset(parameters_1)

    else:
        parameters_2 = (type, margin_name, swap_name, txt_margin, txt_swap, p_0 - 10000, p_0, 1000, last, ctVal, pos_pos, pos_imr, availEq, p_max_bi, pend_pos, pend_px)
        p_log_p, p_0, p_1, p_2, p_3, p_4, p_5, p_bzj = rates_match_reset(parameters_2)

        parameters_3 = (type, margin_name, swap_name, txt_margin, txt_swap, p_0 - 1000, p_0, 100, last, ctVal, pos_pos, pos_imr, availEq, p_max_bi, pend_pos, pend_px)
        p_log_p, p_0, p_1, p_2, p_3, p_4, p_5, p_bzj = rates_match_reset(parameters_3)

    return p_log_p, p_0, p_1, p_2, p_3, p_4, p_5, p_bzj


# 资金费 匹配函数
def rates_match_reset(parameters):
    type, margin_name, swap_name, txt_margin, txt_swap, p_min, p_max, p_interval, last, ctVal, pos_pos, pos_imr, availEq, p_max_bi, pend_pos, pend_px = parameters
    p_log = pd.DataFrame(
        columns=('序列', '套利', '需要保证金', '资金使用率%', '杠杆', '杠杆最低保证金率', '杠杆最低保证金', '永续', '永续最低保证金率', '永续最低保证金'))
    index = 0
    for p in range(p_min, p_max, p_interval):
        # 根据杠杆的范围来划定档位
        lever_max, lever_pre = get_lever_cross_info(p, txt_margin, type, last)
        swap_n = (p / last) // ctVal
        swap_max, swap_pre = get_swap_cross_info(swap_n, txt_swap)

        if eval(lever_pre) == 1:
            break

        # -------------------------------
        # d0 序列
        # d1 套利
        # d2 需要保证金
        # d3 资金使用率%
        # d4 杠杆
        # d5 杠杆最低保证金率
        # d6 杠杆最低保证金
        # d7 永续
        # d8 永续最低保证金率
        # d9 永续最低保证金
        # -------------------------------

        d0 = index
        d1 = p
        d2 = p * (eval(swap_pre) + eval(lever_pre))
        d3 = 100 * p / (p * (eval(swap_pre) + eval(lever_pre)))
        d4 = lever_max
        d5 = 100 * eval(lever_pre)
        d6 = p * eval(lever_pre)
        d7 = swap_max
        d8 = 100 * eval(swap_pre)
        d9 = p * eval(swap_pre)

        p_log.loc[index] = [d0, d1, d2, d3, d4, d5, d6, d7, d8, d9]

        pre = 100 * p / (p * (eval(swap_pre) + eval(lever_pre)))

        if pre < 95:
            break

        # 杠杆最低保证金 最大值为限
        if type == "negative":
            if p * eval(lever_pre) * float(lever_max) >= p_max_bi:
                break

        index = index + 1

    pos_imr_s = 0
    pos_imr_m = 0

    # 检查pos仓位持仓数量 检查档位 进行杠杆设置
    if swap_name in list(pos_pos.keys()):
        if margin_name in list(pos_pos.keys()):
            pos_imr_s = eval(pos_imr[swap_name])
            pos_imr_m = eval(pos_imr[margin_name])
        else:
            pos_imr_s = eval(pos_imr[swap_name])
            # 检查pend挂单的数量 添加到保证金里面
            if margin_name in list(pend_pos.keys()):
                # 获取币币杠杆倍数
                margin_lever = accountAPI.get_leverage(instId=margin_name, mgnMode='cross')
                margin_lever = eval(margin_lever["data"][0]["lever"])
                pos_imr_m = pend_pos[margin_name] * pend_px[margin_name] / margin_lever

    # print("已占用保证金\n杠杆{:.2f}\n永续{:.2f}\n合计{:.2f}".format(pos_imr_m, pos_imr_s, pos_imr_m + pos_imr_s))

    # pos_imr_s float 永续合约保证金
    # pos_imr_m float 币币杠杆保证金

    availEq = pos_imr_s + pos_imr_m + availEq

    p_log_m = p_log.to_dict()['套利']
    p_log_d = p_log.to_dict()['需要保证金']
    p_log_lever = p_log.to_dict()['杠杆']
    p_log_lever_u = p_log.to_dict()['杠杆最低保证金']
    p_log_swap = p_log.to_dict()['永续']
    p_log_swap_u = p_log.to_dict()['永续最低保证金']

    p_log_p = 0
    p_bzj = 0

    if availEq > p_log_d[list(p_log_d.keys())[-1]]:
        availEq = p_log_d[list(p_log_d.keys())[-1]]

    if p_interval == 100:
        for log in list(p_log_d.keys()):
            if availEq <= p_log_d[log]:
                if log == 0:
                    p_log_p = 0
                else:
                    p_log_p = log - 1
                    p_bzj = p_log_d[p_log_p]
                # print('\n需要保证金', p_bzj, '\n杠杆', p_log_lever[p_log_p], '杠杆最低保证金', p_log_lever_u[p_log_p],'\n永续', p_log_swap[p_log_p], '永续最低保证金', p_log_swap_u[p_log_p])

                break

    else:
        for log in list(p_log_d.keys()):
            if availEq <= p_log_d[log]:
                p_log_p = log
                # print("区间范围为", p_log_p, '套利金额', p_log_m[p_log_p], '保证金', p_log_d[p_log_p])
                break

    # -------------------------------
    # p_log_p   区间范围
    # p_0       套利金额
    # p_1       保证金
    # p_2       杠杆
    # p_3       杠杆最低保证金
    # p_4       永续
    # p_5       永续最低保证金
    # p_bzj     保证金
    # -------------------------------

    p_0 = p_log_m[p_log_p]
    p_1 = p_log_d[p_log_p]
    p_2 = p_log_lever[p_log_p]
    p_3 = p_log_lever_u[p_log_p]
    p_4 = p_log_swap[p_log_p]
    p_5 = p_log_swap_u[p_log_p]

    if swap_name in list(pos_pos.keys()):
        p_bzj = p_1 - pos_imr_s - pos_imr_m
        # print('\n(计算后)本次增加的保证金',p_bzj,'\n杠杆', p_2, '杠杆最低保证金', p_3 - pos_imr_m,'\n永续', p_4, '永续最低保证金', p_5 - pos_imr_s)
        p_1 = p_bzj
        p_3 = p_3 - pos_imr_m
        p_5 = p_5 - pos_imr_s

    return p_log_p, p_0, p_1, p_2, p_3, p_4, p_5, p_bzj

