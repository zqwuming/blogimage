# -*- coding = utf-8 -*-
# @time:2021/12/9 15:25
# Author:ldx
# @File:pos_leverage_fees.py
# @Software:PyCharm

# -------------------------------
# main - 抹平机制 自动检索持仓情况 自动市价抹平多余的杠杆利息
# -------------------------------

from uuid import uuid4
from Private.api import marketAPI, publicAPI, tradeAPI
from Common.common import get_position

def fee_order(margin_name, p_margin, pos_pos):
    client_oid = 'fee' + str(uuid4())[:8]
    # 下单刷新
    margin_info = marketAPI.get_ticker(margin_name)
    p_info = publicAPI.get_instruments(instType='SPOT',instId=margin_name)

    # 获取下单价格 成交价 根据借币还是借U
    if pos_pos[margin_name] > 0:
        # sell = margin_info['data'][0]['askPx']
        side = 'sell'
    else:
        # sell = margin_info['data'][0]['bidPx']
        side = 'buy'

    # 获取最小下单数量
    minSz = p_info['data'][0]['minSz']

    # 计算下单的数量
    if p_margin > float(minSz):
        c = str(p_margin)

        # 杠杆交易下单 - 市价交易
        margin_order = tradeAPI.place_order(instId=margin_name, tdMode='cross', ccy='USDT', clOrdId=client_oid + 'm',
                                           side=side, ordType='market', sz=c, reduceOnly='false')

        print(margin_order)
    else:
        print(margin_name,'少于最小下单数量。')


def pos_fees_process():
    # 持仓信息 获取当前交易对
    pos_name, pos_pos, pos_upl, pos_imr = get_position()

    clear = []
    inter_name = []
    inter_number = []

    for i in pos_name:
        if i[-4:] == 'USDT':
            # 检索有没有对应的SWAP
            for j in pos_name:
                if j[-4:] == 'SWAP':
                    if j == i+'-SWAP':
                        inter = abs(float(pos_pos[i])) - abs(float(pos_pos[j]))

                        if inter <= 0:
                            break

                        inter_name.append(i)
                        inter_number.append(inter)
                        break
            else:
                clear.append(i)

    print('\n本程序即将进行杠杆抹平操作。\n抹平列表为:')

    for j in range(len(inter_name)):
        print(inter_name[j],inter_number[j])

    for k in clear:
        print(k,pos_pos[k])

    yes = input("\nPlease enter any key to start the program!")

    for k in range(len(inter_name)):
        fee_order(inter_name[k], inter_number[k], pos_pos)

    for k in clear:
        cp = tradeAPI.close_positions(instId=k,mgnMode="cross",ccy="USDT")
        print(cp)
