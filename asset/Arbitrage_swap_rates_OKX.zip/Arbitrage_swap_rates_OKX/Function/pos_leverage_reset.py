# -*- coding = utf-8 -*-
# @time:2021/12/7 16:15
# Author:ldx
# @File:pos_leverage_reset.py
# @Software:PyCharm

# -------------------------------
# main - 杠杆重置 实现最优杠杆
# -------------------------------

from time import sleep
from Private.api import accountAPI, marketAPI
from Common.common import account_about, set_leverage
from Common.common_no_print import get_position_no_print, get_pending_no_print
from Common.Transaction_settings import get_ms_info
from Common.public_doc_link_info import v5_public_lever, v5_public_swap, get_interest_rate
from Function.pos_leverage_reset_common import rates_set_settings_match_reset


# 获取持仓的杠杆信息
def get_pos_leverage_info(pos_name):
    pos_leverage_info = []
    for p in pos_name:
        leverage_info = accountAPI.get_leverage(instId=p,mgnMode='cross')
        pos_leverage_info.append(leverage_info['data'][0]['lever'])
    return pos_leverage_info


# 持仓杠杆重置函数
def pos_leverage_reset():
    print('Optimization of position leverage 头寸杠杆优化\n')

    # 现实账户信息
    eq0, availEq0 = account_about()

    print("当前持仓杠杆信息\n")

    # 持仓信息 获取当前交易对
    pos_name, pos_pos, pos_upl, pos_imr = get_position_no_print()
    pend_pos, pend_px, pend_id, pend_time = get_pending_no_print()

    # pos_imr 字典
    if len(pos_name)>0:
        pos_leverage_info = get_pos_leverage_info(pos_name)

        for p in range(len(pos_name)):
            print("标的 {} |杠杆 {} |保证金 {}".format(pos_name[p],pos_leverage_info[p],pos_imr[pos_name[p]]))

    # 检查持仓是否组成组合
    pos_com = []
    for p_l_name in pos_name:
        if p_l_name[-4:] == "USDT":
            p_s_name= p_l_name + '-SWAP'
            # pos存在l与s的组合
            if p_s_name in pos_name:
                pos_com.append(p_l_name[:-5])

    print('\n持仓组合的标的', pos_com)

    print('\n开始计算最优杠杆参数组合')

    pos_leverage_result = {}

    for p_com in pos_com:
        p_name = p_com
        p_name = p_name.upper()
        margin_name = p_name + '-USDT'  # 币币杠杆名称
        swap_name = p_name + '-USDT-SWAP'  # 永续合约名称

        # 计算组合保证金之和
        pos_com_margin = eval(pos_imr[margin_name]) + eval(pos_imr[swap_name])

        ctVal, m_tickSz, s_tickSz, m_lotSz, s_lotSz, m_minSz, s_minSz = get_ms_info(margin_name)  # 获取合约面值

        p_log_p, p_0, p_1, p_2, p_3, p_4, p_5, p_bzj = rates_set_settings_reset(type, margin_name, swap_name, ctVal, pos_pos, pos_imr, pend_pos, pend_px)

        # 最优杠杆分别是 p_2 p_4
        print("标的 {} |最优杠杆 {} {} |保证金 {}".format(p_name,p_2,p_4,pos_com_margin))

        pos_leverage_result[p_name] = [p_2,p_4]

        sleep(2)

    return pos_leverage_result, availEq0


# 修正持仓杠杆 执行重置
def pos_leverage_reset_do(pos_leverage_result,availEq0):
    yes = input("\nPlease enter any key to start the program!\n")

    for p_name in list(pos_leverage_result.keys()):
        margin_name = p_name + '-USDT'  # 币币杠杆名称
        swap_name = p_name + '-USDT-SWAP'  # 永续合约名称

        p_log_margin = pos_leverage_result[p_name][0]
        p_log_swap = pos_leverage_result[p_name][1]

        set_leverage(margin_name, swap_name,p_log_margin,p_log_swap)

    eq1, availEq1 = account_about()

    print("账户U可用由 {:.2f} -> {:.2f} 增加{:.2f} 约{:.2f}%".format(availEq0,availEq1,availEq1-availEq0,100*(availEq1-availEq0)/availEq0))


# 资金费初始化 重置版本
def rates_set_settings_reset(type, margin_name, swap_name, ctVal, pos_pos, pos_imr, pend_pos, pend_px):

    txt_margin = v5_public_lever(margin_name)
    txt_swap = v5_public_swap(margin_name)

    # 刷新获取价格
    swap_info = marketAPI.get_ticker(swap_name)
    last = eval(swap_info['data'][0]['last'])

    account_info = accountAPI.get_account('USDT')
    a_usdt = account_info['data'][0]['details'][0]

    availEq = eval(a_usdt['availEq'])

    if type == "positive":
        p_max_usdt = int(eval(txt_margin["data"][-1]["quoteMaxBorrow"]))  # 标的杠杆最大借U量
        p_max = float(get_interest_rate(m_name='USDT'))  # 当前账号等级最多可借U

        if p_max < p_max_usdt:
            p_max_usdt = p_max

        # 留出部分空间浮动 使用95%可用保证金
        availEq = 0.95 * availEq

        p_max_bi = 0

        parameters = (type, margin_name, swap_name, txt_margin, txt_swap, last, ctVal, pos_pos, pos_imr, availEq, p_max_usdt, p_max_bi, pend_pos, pend_px)
        p_log_p, p_0, p_1, p_2, p_3, p_4, p_5, p_bzj = rates_set_settings_match_reset(parameters)

    else:
        p_max_bi = int(eval(txt_margin["data"][-1]["maxAmount"]))  # 该标的最多借B多少
        p_name = margin_name[:-5]
        p_max = float(get_interest_rate(m_name=p_name))  # 该账户最多借B多少

        if p_max < p_max_bi:
            p_max_bi = p_max

        p_max_bi = int(last * p_max_bi)

        availEq = 0.95 * availEq

        p_max_usdt = 0

        parameters = (type, margin_name, swap_name, txt_margin, txt_swap, last, ctVal, pos_pos, pos_imr, availEq, p_max_usdt, p_max_bi, pend_pos, pend_px)
        p_log_p, p_0, p_1, p_2, p_3, p_4, p_5, p_bzj = rates_set_settings_match_reset(parameters)

    return p_log_p, p_0, p_1, p_2, p_3, p_4, p_5, p_bzj


if __name__ == '__main__':
    pass