# -*- coding = utf-8 -*-
# @time:2021/12/3 14:01
# Author:ldx
# @File:common.py
# @Software:PyCharm

from time import sleep
from Private.api import accountAPI, publicAPI, tradeAPI, marketAPI

# 查看账户配置 与 账户信息
def account_about():
    account_config = accountAPI.get_account_config()
    a_config = account_config['data'][0]

    print("\n---------------------------"
          "\n\n账户ID:",a_config['uid'],
          "账户层级:",a_config['acctLv'],
          "持仓方式:",a_config['posMode'],
          "计算本位:",a_config['greeksType'])

    account_info = accountAPI.get_account('USDT')
    a_usdt = account_info['data'][0]['details'][0]

    eq = eval(a_usdt['eq'])
    availEq = eval(a_usdt['availEq'])

    print("总账户权益:{:.2f}".format(eval(account_info['data'][0]['totalEq'])),
          "账户U余额:{:.2f}".format(eval(a_usdt['cashBal'])),
          "\n账户U权益:{:.2f}".format(eval(a_usdt['eq'])),
          "账户U可用:{:.2f}".format(eval(a_usdt['availEq'])),
          '\n\n----------------------------')

    return eq, availEq


# 获取标的名称 和 金额数量 构造函数变量
def prepare_var():
    # -------------------------------
    # spot_name str 现货名称
    # margin_name str 币币杠杆名称
    # swap_name str 永续合约名称
    # p_name str 公共名称 例如 BTC ETH
    # -------------------------------
    p_name = input("请输入标的的名称：")
    p_name = p_name.upper()
    spot_name = p_name + '-USDT'
    margin_name = p_name + '-USDT'
    swap_name = p_name + '-USDT-SWAP'

    return (spot_name, margin_name, swap_name, p_name)


# 查询持仓情况 Get Positions
def get_position():
    # -------------------------------
    # pos_name list 持仓标的名称
    # pos_pos dict 持仓的具体数量(币)
    # pos_upl dict 未实现收益
    # pos_imr dict 初始保证金(USDT)
    # -------------------------------
    get_pos = accountAPI.get_positions()
    print("\n当前持仓情况")
    pos = get_pos['data']
    pos_name = []
    pos_pos = {}
    pos_upl = {}
    pos_imr = {}
    for p in range(len(pos)):
        if pos[p]['posCcy'] == 'USDT':
            pos_p = eval(pos[p]['liab'])
        else:
            pos_p = eval(pos[p]['pos'])
            if pos[p]['instType'] == 'SWAP':
                swap_info = publicAPI.get_instruments('SWAP', pos[p]['instId'][:-5])
                ctVal = eval(swap_info['data'][0]['ctVal'])
                pos_p = eval(pos[p]['pos']) * ctVal

        instType = {'SWAP':'永续','MARGIN':'杠杆','FUTURES':'期货'}
        posSide = {'short':'正资金费 做空','long':'负资金费 做多','net':'借币  '}

        print("\n{} {}{} ID:{} 持仓数量:{} 开仓均价:{:.3f} 当前价格:{:.3f} 未实现收益:{:.3f}".format(instType[pos[p]['instType']],posSide[pos[p]['posSide']],pos[p]['posCcy'],pos[p]['instId'],pos_p,eval(pos[p]['avgPx']),eval(pos[p]['last']),eval(pos[p]['upl'])))

        pos_name.append(pos[p]['instId'])
        pos_pos[pos[p]['instId']] = pos_p
        pos_upl[pos[p]['instId']] = pos[p]['upl']
        pos_imr[pos[p]['instId']] = pos[p]['imr']

    return pos_name,pos_pos,pos_upl,pos_imr


# 查询挂单情况
def get_pending():
    # -------------------------------
    # pend_pos dict 挂单数量 swap为张 margin为币
    # pend_px dict 挂单委托价格
    # pend_id dict 挂单id
    # pend_time dict 挂单时间
    # -------------------------------
    get_pend = tradeAPI.get_order_list()
    print("\n当前挂单情况")
    pend = get_pend['data']
    pend_pos = {}
    pend_px = {}
    pend_id = {}
    pend_time = {}

    instType = {'SWAP': '永续', 'MARGIN': '杠杆', 'FUTURES': '期货'}

    for p in range(len(pend)):
        print("\n{} {} 委托数量:{} 委托价格:{} 状态:{}".format(pend[p]['instId'],instType[pend[p]['instType']],pend[p]['sz'],pend[p]['px'],order_state(pend[p]['state'])))
        pend_pos[pend[p]['instId']] = float(pend[p]['sz'])
        pend_px[pend[p]['instId']]= float(pend[p]['px'])
        pend_id[pend[p]['instId']] = pend[p]['ordId']
        pend_time[pend[p]['instId']] = [pend[p]['uTime'],pend[p]['cTime']]

    return pend_pos, pend_px, pend_id, pend_time


# 订单状态
def order_state(n):
    if n == "live":
        return '等待成交'
    elif n == "partially_filled":
        return '部分成交'
    elif n == "filled":
        return '完全成交 OK!'
    elif n == "canceled":
        return '撤单成功'
    else:
        return '订单错误'


# 杠杆设置 初始化设置
def set_leverage(margin_name, swap_name, p_log_margin, p_log_swap):
    try:
        accountAPI.set_leverage(instId=margin_name, lever=str(p_log_margin), mgnMode='cross')
        sleep(0.5)

        accountAPI.set_leverage(instId=swap_name, lever=str(p_log_swap), mgnMode='cross')
        sleep(0.5)

        print("\n{}最优杠杆已设置完成。".format(margin_name[:-5]))

    except(IndexError):
        print("The program runs incorrectly, please try again later.")


# 查询订单情况
def inquire_info(client_oid, margin_name, swap_name, ctVal):

    m_order = tradeAPI.get_orders(margin_name, clOrdId = client_oid + 'm')
    s_order = tradeAPI.get_orders(swap_name, clOrdId = client_oid + 's')

    m_order = m_order['data'][0]
    s_order = s_order['data'][0]

    m_state = order_state(m_order['state'])
    s_state = order_state(s_order['state'])

    # 刷新价格
    margin_info = marketAPI.get_ticker(margin_name)
    swap_info = marketAPI.get_ticker(swap_name)

    margin_p = margin_info['data'][0]['last']
    swap_p = swap_info['data'][0]['last']


    print("{} 永续 {} {}|{} {}|{}  {} 现货 {} {}|{} {}|{}".format(swap_p, s_state, s_order['avgPx'], s_order['px'], eval(s_order['accFillSz'])*ctVal, eval(s_order['sz'])*ctVal,
                                                             margin_p, m_state,m_order['avgPx'], m_order['px'], m_order['accFillSz'], m_order['sz']))

    return s_order['state'],m_order['state'],s_order['avgPx'],m_order['avgPx']
