# -*- coding = utf-8 -*-
# @time:2021/12/5 19:28
# Author:ldx
# @File:Transaction_ways.py
# @Software:PyCharm

# -------------------------------
# 关于交易方式 比如 追单模式：追着买一卖一价格更新价格
# -------------------------------

import time as t
from Private.api import *
from Common.common import order_state

def pressing_transaction_open(type, swap_name, client_oid, ctVal):

    # s_avgPx float 永续合约成交均价

    s_time = 0

    while True:
        s_order = tradeAPI.get_orders(swap_name, clOrdId=client_oid + 's')

        s_order = s_order['data'][0]
        s_state = order_state(s_order['state'])

        print("永续 {} {}|{} {}|{}  {}s".format(s_state, s_order['avgPx'], s_order['px'],
                                              eval(s_order['accFillSz']) * ctVal, eval(s_order['sz']) * ctVal, s_time))

        if s_order['state'] == 'filled':
            s_avgPx = eval(s_order['avgPx']) * (1 + slippage)
            print("永续已优先下单。")
            break

        # 下单刷新
        swap_info = marketAPI.get_ticker(swap_name)

        if type == 'positive':
            price = swap_info['data'][0]['askPx']
        else:
            price = swap_info['data'][0]['bidPx']

        amend_s = tradeAPI.amend_order(swap_name, clOrdId=client_oid + 's', newPx=price)

        s_time = s_time + 5
        t.sleep(5)

    return s_avgPx


def pressing_transaction_close(type, margin_name, client_oid):

    m_time = 0

    while True:
        m_order = tradeAPI.get_orders(margin_name, clOrdId=client_oid + 'm')

        m_order = m_order['data'][0]
        m_state = order_state(m_order['state'])

        print("现货 {} {}|{} {}|{} {}s".format(m_state, m_order['avgPx'], m_order['px'], m_order['accFillSz'],
                                             m_order['sz'], m_time))

        if m_order['state'] == 'filled':
            m_avgPx = eval(m_order['avgPx'])
            print("杠杆已优先下单。")
            break

        # 下单刷新
        margin_info = marketAPI.get_ticker(margin_name)

        if type == 'positive':
            price = margin_info['data'][0]['askPx']
        else:
            price = margin_info['data'][0]['bidPx']

        amend_m = tradeAPI.amend_order(margin_name, clOrdId=client_oid + 'm', newPx=price)

        m_time = m_time + 5
        t.sleep(5)

    return m_avgPx
