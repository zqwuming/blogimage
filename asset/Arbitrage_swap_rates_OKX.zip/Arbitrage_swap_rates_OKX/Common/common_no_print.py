# -*- coding = utf-8 -*-
# @time:2021/12/7 16:27
# Author:ldx
# @File:common_no_print.py
# @Software:PyCharm

from Private.api import accountAPI, publicAPI, tradeAPI

# 订单状态
def order_state(n):
    if n == "live":
        return '等待成交'
    elif n == "partially_filled":
        return '部分成交'
    elif n == "filled":
        return '完全成交 OK!'
    elif n == "canceled":
        return '撤单成功'
    else:
        return '订单错误'


# 查询持仓情况 Get Positions
def get_position_no_print():
    # -------------------------------
    # pos_name list 持仓标的名称
    # pos_pos dict 持仓的具体数量(币)
    # pos_upl dict 未实现收益
    # pos_imr dict 初始保证金(USDT)
    # -------------------------------
    get_pos = accountAPI.get_positions()
    pos = get_pos['data']
    pos_name = []
    pos_pos = {}
    pos_upl = {}
    pos_imr = {}
    for p in range(len(pos)):
        if pos[p]['posCcy'] == 'USDT':
            pos_p = eval(pos[p]['liab'])
        else:
            pos_p = eval(pos[p]['pos'])
            if pos[p]['instType'] == 'SWAP':
                swap_info = publicAPI.get_instruments('SWAP', pos[p]['instId'][:-5])
                ctVal = eval(swap_info['data'][0]['ctVal'])
                pos_p = eval(pos[p]['pos']) * ctVal

        pos_name.append(pos[p]['instId'])
        pos_pos[pos[p]['instId']] = pos_p
        pos_upl[pos[p]['instId']] = pos[p]['upl']
        pos_imr[pos[p]['instId']] = pos[p]['imr']

    return pos_name,pos_pos,pos_upl,pos_imr


# 查询挂单情况
def get_pending_no_print():
    # -------------------------------
    # pend_pos dict 挂单数量 swap为张 margin为币
    # pend_px dict 挂单委托价格
    # pend_id dict 挂单id
    # pend_time dict 挂单时间
    # -------------------------------
    get_pend = tradeAPI.get_order_list()
    pend = get_pend['data']
    pend_pos = {}
    pend_px = {}
    pend_id = {}
    pend_time = {}

    instType = {'SWAP': '永续', 'MARGIN': '杠杆', 'FUTURES': '期货'}

    for p in range(len(pend)):
        print("\n{} {} 委托数量:{} 委托价格:{} 状态:{}".format(pend[p]['instId'],instType[pend[p]['instType']],pend[p]['sz'],pend[p]['px'],order_state(pend[p]['state'])))
        pend_pos[pend[p]['instId']] = float(pend[p]['sz'])
        pend_px[pend[p]['instId']]= float(pend[p]['px'])
        pend_id[pend[p]['instId']] = pend[p]['ordId']
        pend_time[pend[p]['instId']] = [pend[p]['uTime'],pend[p]['cTime']]

    return pend_pos, pend_px, pend_id, pend_time

