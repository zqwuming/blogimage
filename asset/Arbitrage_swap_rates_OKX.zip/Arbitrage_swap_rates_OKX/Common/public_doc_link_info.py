# -*- coding = utf-8 -*-
# @time:2021/12/3 14:06
# Author:ldx
# @File:public_doc_link_info.py
# @Software:PyCharm

# 公共文档信息查询 包含杠杆接待信息 杠杆利率信息 永续文档 杠杆文档

from urllib.request import urlopen
from Private.api import *
import time as t
import json

# 访问v5杠杆借贷信息 不同等级可借U和数量不同
def get_interest_rate(m_name):
    url = 'https://'+okurl+'/priapi/v5/public/interest-rate'
    txt = urlopen(url).read().decode()
    txt = json.loads(txt)
    d = txt["data"][0]['rates']
    m_max = None
    for i in d:
        if i['symbol'] == m_name:
            m_max = int(i['quota'])
            break
    return m_max


# 访问v2仓位杠杆利率文档链接
def get_rates_history(m_name):
    url = 'https://'+okurl+'/v2/asset/outer/financial/rates-history?t='+str(int(t.time()))+'&currentPage=2&pageLength=1'
    txt = urlopen(url).read().decode()
    txt = json.loads(txt)
    m_rate = ""

    # IndexError: list index out of range 判断是否获取成功
    judge = txt["data"]['ratesHistory']
    if len(judge) > 0:
        d = txt["data"]['ratesHistory'][0]['rateList']
        for i in d:
            if i['symbol'] == m_name:
                m_rate = i['rate']
                break
    else:
        print("动态利率失败 开始载入基础利率")
        url = "https://"+okurl+"/priapi/v5/public/interest-rate-loan-quota?t="+str(int(t.time()))
        txt = urlopen(url).read().decode()
        txt = json.loads(txt)
        # 基础利率
        d = txt["data"][0]["basic"]
        for j in d:
            if j["ccy"] == m_name:
                m_rate = str(100 * eval(j['rate'])) + "%"
                break

    return m_rate


def v5_public_swap(m_name):
    url = 'https://'+okurl+'/priapi/v5/public/tier?t=' + str(int(t.time())) + '&instType=SWAP&uly=' + m_name
    txt = urlopen(url).read().decode()
    txt = json.loads(txt)
    return txt


def v5_public_lever(m_name):
    url = 'https://'+okurl+'/priapi/v5/public/tier?t=' + str(int(t.time())) + '&instType=MARGIN&instId=' + m_name
    txt = urlopen(url).read().decode()
    txt = json.loads(txt)
    return txt


# 资金费访问v5仓位永续文档链接
def get_swap_cross_info(swap_n, txt):
    # 根据合约张数的范围来划定档位
    maxLeverage = ''
    imr = ''
    for k in range(len(txt['data'])):
        if swap_n <= eval(txt['data'][k]['maxAmount']):
            maxLeverage = txt['data'][k]['maxLeverage']
            imr = txt['data'][k]['imr']
            break
    return maxLeverage,imr


# 资金费访问v5仓位杠杆文档链接
def get_lever_cross_info(margin_n, txt, type, last):
    # 根据刚刚数量的范围来划定档位
    maxLeverage = ''
    imr = ''

    if type == 'positive':
        for k in range(len(txt['data'])):
            if margin_n <= eval(txt['data'][k]["quoteMaxBorrow"]):
                maxLeverage = txt['data'][k]['maxLeverage']
                imr = txt['data'][k]['imr']
                break
    else:
        for k in range(len(txt['data'])):
            if margin_n <= eval(txt['data'][k]["maxAmount"]) * last:
                maxLeverage = txt['data'][k]['maxLeverage']
                imr = txt['data'][k]['imr']
                break

    return maxLeverage, imr
