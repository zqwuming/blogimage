# -*- coding = utf-8 -*-
# @time:2021/12/3 15:43
# Author:ldx
# @File:Transaction_settings.py
# @Software:PyCharm

# -------------------------------
# 关于交易的设置
# -------------------------------

import numpy as np
from Private.api import *

# 当前账户交易手续费费率
def fee_info(margin_name):
    # -------------------------------
    # margin_fee float 币币杠杆 maker
    # swap_fee float 永续合约 maker
    # -------------------------------
    margin_fee = accountAPI.get_fee_rates('MARGIN',instId=margin_name)
    swap_fee = accountAPI.get_fee_rates('SWAP',uly=margin_name)
    margin_fee = eval(margin_fee['data'][0]['maker'])
    swap_fee = eval(swap_fee['data'][0]['maker'])
    return margin_fee, swap_fee


# 获取币币杠杆和永续合约的基础信息
def get_ms_info(margin_name):
    # -------------------------------
    # ctVal float 合约面值，仅适用于交割/永续/期权
    # tickSz str 下单价格精度，如 0.0001
    # lotSz str 下单数量精度，如 BTC-USDT-SWAP：1
    # minSz str 最小下单数量
    # -------------------------------
    margin_info = publicAPI.get_instruments('SPOT',uly='',instId=margin_name)
    swap_info = publicAPI.get_instruments('SWAP', margin_name)

    ctVal = eval(swap_info['data'][0]['ctVal'])
    m_tickSz = margin_info['data'][0]['tickSz']
    s_tickSz = swap_info['data'][0]['tickSz']
    m_lotSz = margin_info['data'][0]['lotSz']
    s_lotSz = swap_info['data'][0]['lotSz']
    m_minSz = margin_info['data'][0]['minSz']
    s_minSz = swap_info['data'][0]['minSz']

    return ctVal, m_tickSz, s_tickSz, m_lotSz, s_lotSz, m_minSz, s_minSz


# 获取资金费率
def rate_info(swap_name):
    # rate str 当期资金费率
    rate = publicAPI.get_funding_rate(swap_name)
    rate = rate['data'][0]['fundingRate']
    return rate


# 获取前24个小时交易量 平均交易量 volume(24) 单位：币
def get_volume(margin_name, swap_name, ctVal):
    # -------------------------------
    # spot_volume float 现货24小时交易量 单位：币
    # swap_volume float 永续合约24小时交易量 单位：币
    # -------------------------------
    spot_index = marketAPI.get_candlesticks(margin_name, bar='1H')
    spot_index = spot_index['data']
    v_sum = 0
    for v in spot_index[1:25]:
        v_sum += eval(v[5])
    spot_volume = v_sum / 24
    swap_index = marketAPI.get_candlesticks(swap_name, bar='1H')
    swap_index = swap_index['data']
    v_sum = 0
    for v in swap_index[1:25]:
        v_sum += eval(v[5])

    swap_volume = v_sum / 24 * ctVal

    return spot_volume , swap_volume


# 获取前24个小时每3分钟的 median
def get_median(margin_name,swap_name):
    # -------------------------------
    # spot_median float 现货24小时平均价格 median
    # swap_median float 永续合约24小时平均价格 median
    # -------------------------------
    spot_index = marketAPI.get_candlesticks(margin_name, bar='3m')
    spot_index = spot_index['data']
    v_price = []
    for v in spot_index[:480]:
        v_price.append(eval(v[4]))
    spot_median = np.median(v_price)
    swap_index = marketAPI.get_candlesticks(swap_name, bar='3m')
    swap_index = swap_index['data']
    v_price = []
    for v in swap_index[:480]:
        v_price.append(eval(v[4]))
    swap_median = np.median(v_price)
    return spot_median , swap_median


# 计算median 交易量 建议交易金额 33%(24h)交易额 公式：币x价格
def calculation(margin_name, swap_name, ctVal):
    # -------------------------------
    # median float 最小交易量 单位:币
    # swap_last float 最新永续合约价格
    # max_money float 最小可交易金额
    # -------------------------------
    spot_volume , swap_volume = get_volume(margin_name, swap_name, ctVal)
    spot_median , swap_median = get_median(margin_name, swap_name)

    swap_info = marketAPI.get_ticker(swap_name)
    swap_last = eval(swap_info['data'][0]['last'])

    median = min(spot_median, swap_median)
    volume = min(spot_volume, swap_volume)

    max_money = min(0.33 * spot_volume * spot_median, 0.33 * swap_volume * swap_median)

    print('\n'+"--" * 20)
    print("\n交易参数")
    print("\nmedian {} ; volume {:.3f} ; 33% volume of 24h transaction: {:.3f} USDT".format( median, volume, max_money ))
    print("目前价格: {} USDT".format(swap_last))
    print("偏差值为: {:.3f}%".format(100 * (swap_last - median) / swap_last))
    print('\n'+"--" * 20)

    return median, swap_last, max_money


# 计算偏离度函数
def calculation_dev(swap_name, median, string):
    # dev float 偏离度
    swap_info = marketAPI.get_ticker(swap_name)
    swap_last = eval(swap_info['data'][0]['last'])

    dev = (swap_last - median) / swap_last
    print("偏差值为: {:.2f}%  {}".format(100 * dev,string))
    return dev


# 下单价格单位修正 如果遇到科学计数法修正到最小单位的格式
def make_px(s_avgPx,m_tickSz):
    # price str 修正后的价格
    mx = '.{}f'.format(str(m_tickSz.count("0")))
    price = format(s_avgPx,mx)
    return price
