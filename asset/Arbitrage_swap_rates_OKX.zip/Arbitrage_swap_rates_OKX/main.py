# -*- coding = utf-8 -*-
# @time:2021/12/3 13:50
# Author:ldx
# @File:main.py
# @Software:PyCharm

from Function.swap_rates import open_swap_rates, close_swap_rates
from Function.pos_leverage_reset import pos_leverage_reset, pos_leverage_reset_do
from Function.total_amount_20_OKEX import total_amount_20_okex
from Function.pos_limit_trading_volume import pos_limit_vol
from Function.pos_leverage_fees import pos_fees_process

if __name__ == '__main__':
    print('欢迎使用 OKex_v5.0 资金费套利(统一账户)\n')
    print('执行前请确认套利类型\n'
          '\n1 正资金费套利'
          '\n2 负资金费套利'
          '\n3 持仓杠杆重置最优设置'
          '\n4 杠杆账户零头抹平'
          '\n5 OKEX前20可套利资金总量'
          '\n6 查询当前持仓标的交易限额')

    n = input('\n输入数字代码...')

    if n == "1":
        print('\n请选择执行\n \n1 开仓 \n2 平仓')

        j = input('\n输入数字代码...')

        if j == '1':
            print("\n即将进行开仓操作 ")
            try:
                open_swap_rates(type='positive')
            except():
                print("The program runs incorrectly, please try again later.")

        elif j == '2':
            print("\n即将进行平仓操作 ")
            try:
                close_swap_rates(type='positive')
            except():
                print("The program runs incorrectly, please try again later.")

        else:
            print('程序结束。')
            exit()

    elif n == '2':
        print('\n请选择执行\n \n1 开仓 \n2 平仓')

        j = input('\n输入数字代码...')

        if j == '1':
            print("即将进行开仓操作")
            try:
                open_swap_rates(type='negative')
            except():
                print("The program runs incorrectly, please try again later.")
        elif j == '2':
            print("即将进行平仓操作")
            try:
                close_swap_rates(type='negative')
            except():
                print("The program runs incorrectly, please try again later.")
        else:
            print('程序结束。')
            exit()

    elif n == '3':
        pos_leverage_result, availEq0 = pos_leverage_reset()
        pos_leverage_reset_do(pos_leverage_result, availEq0)

    elif n == "4":
        pos_fees_process()

    elif n == "5":
        total_amount_20_okex()

    elif n == "6":
        pos_limit_vol()

    else:
        print('程序结束。')
        exit()
